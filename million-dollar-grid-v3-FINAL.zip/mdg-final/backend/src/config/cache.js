// In-memory cache - replace with Redis in production
const cache = new Map();

const getCacheClient = () => ({
    get: async (key) => cache.get(key) || null,
    setEx: async (key, ttl, value) => {
        cache.set(key, value);
        setTimeout(() => cache.delete(key), ttl * 1000);
    },
    del: async (key) => cache.delete(key),
});

module.exports = { getCacheClient };