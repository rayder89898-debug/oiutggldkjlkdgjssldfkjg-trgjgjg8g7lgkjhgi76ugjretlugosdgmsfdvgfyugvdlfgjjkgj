const xss = require('xss');

const sanitizeInput = (req, res, next) => {
    if (req.body) {
        const clean = (val) => {
            if (typeof val === 'string') {
                return xss(val, { whiteList: {}, stripIgnoreTag: true, stripIgnoreTagBody: ['script','style'] });
            }
            if (typeof val === 'object' && val !== null && !Array.isArray(val)) {
                const out = {};
                for (const k of Object.keys(val)) out[k] = clean(val[k]);
                return out;
            }
            return val;
        };
        req.body = clean(req.body);
    }
    next();
};

const securityHeaders = (req, res, next) => {
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    next();
};

module.exports = { sanitizeInput, securityHeaders };