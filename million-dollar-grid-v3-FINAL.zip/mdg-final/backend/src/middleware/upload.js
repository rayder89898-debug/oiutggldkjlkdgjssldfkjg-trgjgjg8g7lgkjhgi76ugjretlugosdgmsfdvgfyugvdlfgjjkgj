const multer = require('multer');
const sharp  = require('sharp');
const path   = require('path');
const fs     = require('fs');
const crypto = require('crypto');

const ALLOWED_MIMETYPES = ['image/jpeg','image/png','image/gif','image/webp'];
const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
const MAX_WIDTH = 5000;
const MAX_HEIGHT = 5000;

const uploadDir = path.join(__dirname, '../../uploads/ads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: MAX_FILE_SIZE, files: 1 },
    fileFilter: (req, file, cb) => {
        if (!ALLOWED_MIMETYPES.includes(file.mimetype)) {
            return cb(new Error('Only JPEG, PNG, GIF, WebP allowed'), false);
        }
        cb(null, true);
    },
});

const validateImageUpload = [
    upload.single('image'),
    async (req, res, next) => {
        if (!req.file) return next();
        try {
            const buf = req.file.buffer;

            // Verify magic bytes (not just MIME)
            const isJPEG = buf[0] === 0xFF && buf[1] === 0xD8;
            const isPNG  = buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4E && buf[3] === 0x47;
            const isGIF  = buf[0] === 0x47 && buf[1] === 0x49 && buf[2] === 0x46;
            const isWEBP = buf.length > 12 && buf[8] === 0x57 && buf[9] === 0x45 && buf[10] === 0x42;

            if (!isJPEG && !isPNG && !isGIF && !isWEBP) {
                return res.status(400).json({ error: 'Invalid file format' });
            }

            const image = sharp(buf);
            const meta  = await image.metadata();

            if (meta.width > MAX_WIDTH || meta.height > MAX_HEIGHT) {
                return res.status(400).json({ error: `Image too large. Max ${MAX_WIDTH}x${MAX_HEIGHT}px` });
            }

            // Secure random filename - no path traversal possible
            const hash = crypto.randomBytes(32).toString('hex');
            const ext  = isJPEG ? 'jpg' : isPNG ? 'png' : isGIF ? 'gif' : 'webp';
            const filename = `${hash}.${ext}`;
            const outputPath = path.join(uploadDir, filename);

            // Strip EXIF metadata (privacy + security)
            await image.rotate().toFile(outputPath);

            req.file.filename = filename;
            req.file.path = outputPath;
            req.file.processedWidth = meta.width;
            req.file.processedHeight = meta.height;
            next();
        } catch {
            return res.status(400).json({ error: 'Failed to process image' });
        }
    }
];

module.exports = { validateImageUpload };