const jwt = require('jsonwebtoken');
const { pool } = require('../config/database');

const authenticate = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader?.startsWith('Bearer ')) {
            return res.status(401).json({ error: 'Authorization token required' });
        }
        const token = authHeader.substring(7);
        if (!token || token.length > 1000) {
            return res.status(401).json({ error: 'Invalid token format' });
        }
        const decoded = jwt.verify(token, process.env.JWT_SECRET, {
            issuer: 'milliondollargrid.com',
            algorithms: ['HS256'],
        });
        const result = await pool.query(
            'SELECT id, email, role, is_banned FROM users WHERE id = $1',
            [decoded.id]
        );
        if (!result.rows.length || result.rows[0].is_banned) {
            return res.status(401).json({ error: 'Invalid or suspended account' });
        }
        req.user = result.rows[0];
        next();
    } catch (error) {
        if (error.name === 'TokenExpiredError') return res.status(401).json({ error: 'Token expired' });
        if (error.name === 'JsonWebTokenError') return res.status(401).json({ error: 'Invalid token' });
        return res.status(401).json({ error: 'Authentication failed' });
    }
};

const optionalAuth = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        if (authHeader?.startsWith('Bearer ')) {
            const token = authHeader.substring(7);
            if (token && token.length <= 1000) {
                const decoded = jwt.verify(token, process.env.JWT_SECRET, {
                    algorithms: ['HS256'],
                    issuer: 'milliondollargrid.com',
                });
                req.user = decoded;
            }
        }
    } catch {}
    next();
};

const requireAdmin = (req, res, next) => {
    if (!['admin', 'superadmin'].includes(req.user?.role)) {
        return res.status(404).json({ error: 'Not found' }); // 404 not 403 - hides admin existence
    }
    next();
};

// Extra admin security: IP whitelist + secret header
const adminSecurityCheck = (req, res, next) => {
    const ALLOWED_IPS = (process.env.ADMIN_ALLOWED_IPS || '').split(',').filter(Boolean);
    const SECRET_HEADER = process.env.ADMIN_SECRET_HEADER;

    if (ALLOWED_IPS.length > 0) {
        const clientIP = req.ip || req.connection?.remoteAddress || '';
        const normalizedIP = clientIP.replace('::ffff:', '');
        if (!ALLOWED_IPS.includes(normalizedIP) && !ALLOWED_IPS.includes(clientIP)) {
            return res.status(404).json({ error: 'Not found' });
        }
    }

    if (SECRET_HEADER) {
        const providedHeader = req.headers['x-admin-access'];
        if (providedHeader !== SECRET_HEADER) {
            return res.status(404).json({ error: 'Not found' });
        }
    }

    next();
};

module.exports = { authenticate, optionalAuth, requireAdmin, adminSecurityCheck };