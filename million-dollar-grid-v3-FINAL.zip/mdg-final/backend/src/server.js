require('dotenv').config();

// ── Startup security validation ───────────────────────────────
if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
    console.error('❌ FATAL: JWT_SECRET missing or too short (min 32 chars). Exiting.');
    process.exit(1);
}
if (process.env.NODE_ENV === 'production' &&
    process.env.JWT_SECRET === 'CHANGE_THIS_TO_RANDOM_64_CHAR_STRING_MINIMUM') {
    console.error('❌ FATAL: Default JWT_SECRET in production! Exiting.');
    process.exit(1);
}

const express    = require('express');
const http       = require('http');
const WebSocket  = require('ws');
const helmet     = require('helmet');
const cors       = require('cors');
const rateLimit  = require('express-rate-limit');
const compression = require('compression');
const morgan     = require('morgan');
const hpp        = require('hpp');
const path       = require('path');
const cron       = require('node-cron');
const { v4: uuidv4 } = require('uuid');

const authRoutes    = require('./routes/auth');
const pixelRoutes   = require('./routes/pixels');
const adRoutes      = require('./routes/advertisements');
const paymentRoutes = require('./routes/payments');
const adminRoutes   = require('./routes/admin');
const statsRoutes   = require('./routes/stats');

const { releaseExpiredReservations } = require('./services/pixelService');
const { setupWebSocket }             = require('./services/websocketService');
const { pool }                       = require('./config/database');
const logger                         = require('./config/logger');
const { securityHeaders }            = require('./middleware/sanitize');

const app    = express();
const server = http.createServer(app);

app.set('trust proxy', 1);

// ── Helmet ────────────────────────────────────────────────────
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc:   ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
            fontSrc:    ["'self'", "https://fonts.gstatic.com"],
            imgSrc:     ["'self'", "data:", "https:", "blob:"],
            scriptSrc:  ["'self'"],
            connectSrc: ["'self'", "wss:", "ws:"],
            frameSrc:   ["'none'"],
            objectSrc:  ["'none'"],
        },
    },
    crossOriginEmbedderPolicy: false,
    hsts: process.env.NODE_ENV === 'production' ? { maxAge: 31536000, includeSubDomains: true } : false,
}));

app.use(securityHeaders);

// ── CORS ──────────────────────────────────────────────────────
app.use(cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-CSRF-Token', 'X-Admin-Access'],
}));

app.use(hpp());
app.use(compression());

// ── Logging (sanitized - no sensitive data) ───────────────────
app.use(morgan(':method :url :status :res[content-length] - :response-time ms', {
    skip: (req) => req.path === '/health',
    stream: { write: (msg) => logger.info(msg.trim()) },
}));

// ── Body parsing ──────────────────────────────────────────────
app.use((req, res, next) => {
    if (req.path.includes('/webhooks/')) return next();
    express.json({ limit: '10kb' })(req, res, next);
});
app.use(express.urlencoded({ extended: false, limit: '10kb' }));

// ── Content-Type enforcement ──────────────────────────────────
app.use((req, res, next) => {
    if (['POST','PUT','PATCH'].includes(req.method)) {
        const ct = req.headers['content-type'] || '';
        if (!ct.includes('application/json') &&
            !ct.includes('multipart/form-data') &&
            !ct.includes('application/x-www-form-urlencoded') &&
            !req.path.includes('/webhooks/')) {
            return res.status(415).json({ error: 'Unsupported Media Type' });
        }
    }
    next();
});

// ── Rate Limiters ─────────────────────────────────────────────
const globalLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 200,
    message: { error: 'Too many requests, please try again later.' },
    standardHeaders: true,
    legacyHeaders: false,
    skip: (req) => req.path === '/health',
});

const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 10,
    message: { error: 'Too many login attempts. Please wait 15 minutes.' },
    skipSuccessfulRequests: true,
});

const paymentLimiter = rateLimit({
    windowMs: 60 * 60 * 1000,
    max: 5,
    message: { error: 'Too many payment requests.' },
});

app.use(globalLimiter);

// ── CSRF Protection ───────────────────────────────────────────
const csrfTokens  = new Map();
const CSRF_MAX    = 10000;
const CSRF_TTL    = 3600000;

const cleanCsrf = () => {
    const now = Date.now();
    for (const [t, exp] of csrfTokens) if (now > exp) csrfTokens.delete(t);
};
setInterval(cleanCsrf, 10 * 60 * 1000);

app.get('/api/csrf-token', (req, res) => {
    if (csrfTokens.size >= CSRF_MAX) cleanCsrf();
    if (csrfTokens.size >= CSRF_MAX) return res.status(429).json({ error: 'Too many CSRF tokens' });
    const token = uuidv4();
    csrfTokens.set(token, Date.now() + CSRF_TTL);
    res.json({ csrfToken: token });
});

app.use((req, res, next) => {
    if (['GET','HEAD','OPTIONS'].includes(req.method)) return next();
    if (req.path.includes('/webhooks/')) return next();
    const ct = req.headers['content-type'] || '';
    if (ct.includes('multipart/form-data')) return next(); // Upload - protected by JWT
    const token = req.headers['x-csrf-token'];
    if (!token || token.length > 100 || !csrfTokens.has(token)) {
        return res.status(403).json({ error: 'Invalid CSRF token' });
    }
    const exp = csrfTokens.get(token);
    if (Date.now() > exp) { csrfTokens.delete(token); return res.status(403).json({ error: 'CSRF token expired' }); }
    csrfTokens.delete(token);
    next();
});

// ── Static uploads ────────────────────────────────────────────
app.use('/uploads', express.static(path.join(__dirname, '../uploads'), {
    maxAge: '7d',
    etag: true,
    setHeaders: (res) => {
        res.setHeader('X-Content-Type-Options', 'nosniff');
        res.setHeader('Content-Disposition', 'inline');
    },
}));

// ── Routes ────────────────────────────────────────────────────
const ADMIN_SECRET = process.env.ADMIN_PATH_SECRET || 'admin';
app.use('/api/auth',                    authLimiter,    authRoutes);
app.use('/api/pixels',                                  pixelRoutes);
app.use('/api/advertisements',                          adRoutes);
app.use('/api/payments',                paymentLimiter, paymentRoutes);
app.use(`/api/${ADMIN_SECRET}`,                         adminRoutes);  // Hidden admin path
app.use('/api/stats',                                   statsRoutes);

app.get('/health', (req, res) => res.json({ status: 'ok' }));

// ── 404 ───────────────────────────────────────────────────────
app.use((req, res) => res.status(404).json({ error: 'Not found' }));

// ── Global error handler ──────────────────────────────────────
app.use((err, req, res, next) => {
    logger.error('Unhandled error:', { error: err.message, url: req.url });
    res.status(err.status || 500).json({
        error: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message,
    });
});

// ── WebSocket ─────────────────────────────────────────────────
const wss = new WebSocket.Server({ server, path: '/ws' });
setupWebSocket(wss);

// ── Cron ──────────────────────────────────────────────────────
cron.schedule('*/5 * * * *', async () => {
    try { await releaseExpiredReservations(); }
    catch (err) { logger.error('Reservation cleanup failed:', err); }
});

// ── Start ─────────────────────────────────────────────────────
const PORT = parseInt(process.env.PORT) || 5000;
server.listen(PORT, () => {
    logger.info(`🚀 Server running on port ${PORT}`);
    logger.info(`🔒 Security: Helmet, CORS, CSRF, Rate Limiting, HPP active`);
    logger.info(`🕵️ Admin path: /api/${ADMIN_SECRET}`);
    logger.info(`Environment: ${process.env.NODE_ENV}`);
});

process.on('SIGTERM', async () => {
    server.close(async () => { await pool.end(); process.exit(0); });
});

module.exports = { app, server };