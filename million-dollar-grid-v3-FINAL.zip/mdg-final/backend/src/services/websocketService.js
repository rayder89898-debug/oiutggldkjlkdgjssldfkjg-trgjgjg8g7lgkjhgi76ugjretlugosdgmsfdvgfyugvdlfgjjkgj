const WebSocket = require('ws');
const logger = require('../config/logger');

let wss = null;
const clients = new Set();

const setupWebSocket = (websocketServer) => {
    wss = websocketServer;
    wss.on('connection', (ws, req) => {
        clients.add(ws);
        ws.isAlive = true;
        ws.send(JSON.stringify({ type: 'CONNECTED', clientCount: clients.size }));

        ws.on('message', (message) => {
            try {
                if (message.length > 1024) return; // DoS protection
                const data = JSON.parse(message.toString());
                if (data.type === 'PING') ws.send(JSON.stringify({ type: 'PONG' }));
            } catch {}
        });

        ws.on('close', () => clients.delete(ws));
        ws.on('error', () => clients.delete(ws));
        ws.on('pong', () => { ws.isAlive = true; });
    });

    const heartbeat = setInterval(() => {
        wss.clients.forEach((ws) => {
            if (!ws.isAlive) { clients.delete(ws); return ws.terminate(); }
            ws.isAlive = false;
            ws.ping();
        });
    }, 30000);

    wss.on('close', () => clearInterval(heartbeat));
};

const broadcastPixelUpdate = (data) => {
    if (!wss) return;
    const message = JSON.stringify(data);
    clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) client.send(message);
        else clients.delete(client);
    });
};

module.exports = { setupWebSocket, broadcastPixelUpdate };