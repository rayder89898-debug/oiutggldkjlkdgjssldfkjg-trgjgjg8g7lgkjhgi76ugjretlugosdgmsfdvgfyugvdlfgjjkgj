const { pool } = require('../config/database');

const releaseExpiredReservations = async () => {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const expired = await client.query(
            'SELECT pixel_ids FROM pixel_reservations WHERE expires_at < NOW()'
        );
        if (expired.rows.length > 0) {
            const allIds = expired.rows.flatMap(r => r.pixel_ids);
            await client.query(
                'UPDATE pixels SET status = $1, reserved_at = NULL WHERE id = ANY($2::bigint[])',
                ['available', allIds]
            );
            await client.query('DELETE FROM pixel_reservations WHERE expires_at < NOW()');
        }
        await client.query('COMMIT');
    } catch (err) {
        await client.query('ROLLBACK');
        throw err;
    } finally {
        client.release();
    }
};

module.exports = { releaseExpiredReservations };