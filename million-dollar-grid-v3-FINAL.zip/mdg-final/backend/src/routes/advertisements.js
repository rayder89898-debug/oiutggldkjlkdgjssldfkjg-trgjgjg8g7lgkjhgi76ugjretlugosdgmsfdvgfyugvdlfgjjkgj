const express = require('express');
const router  = express.Router();
const { pool } = require('../config/database');

router.get('/', async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT id, advertiser_name, website_url, description,
                   image_url, alt_text, pixel_count, click_count, created_at
            FROM advertisements
            WHERE is_active=true AND status='active'
            ORDER BY created_at DESC
        `);
        res.json(result.rows);
    } catch { res.status(500).json({ error: 'Failed to fetch advertisements' }); }
});

module.exports = router;