const express = require('express');
const router  = express.Router();
const { pool } = require('../config/database');

router.get('/', async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT
                COUNT(*) FILTER (WHERE status='available') AS available,
                COUNT(*) FILTER (WHERE status='sold')      AS sold,
                COUNT(*) FILTER (WHERE status='reserved')  AS reserved,
                COUNT(*) AS total
            FROM pixels
        `);
        res.json(result.rows[0]);
    } catch { res.status(500).json({ error: 'Failed to get stats' }); }
});

module.exports = router;