const express = require('express');
const router  = require('express').Router();
const stripe  = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { body, validationResult } = require('express-validator');
const { authenticate } = require('../middleware/auth');
const { validateImageUpload } = require('../middleware/upload');
const { sanitizeInput } = require('../middleware/sanitize');
const { pool }   = require('../config/database');
const { broadcastPixelUpdate } = require('../services/websocketService');
const logger = require('../config/logger');

// POST /api/payments/create-stripe-session
router.post('/create-stripe-session', authenticate, [
    body('pixelIds').isArray({ min: 1, max: 10000 }),
    body('pixelIds.*').isInt({ min: 1, max: 10000000 }),
    body('reservationId').isUUID(),
    body('advertiserName').trim().isLength({ min: 1, max: 100 }).escape(),
    body('websiteUrl').isURL({ protocols: ['http','https'], require_protocol: true }).isLength({ max: 500 }),
    body('description').trim().isLength({ max: 500 }).optional(),
], sanitizeInput, async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

        const { pixelIds, reservationId, advertiserName, websiteUrl, description } = req.body;
        const userId = req.user.id;
        const uniquePixelIds = [...new Set(pixelIds)];
        const pixelCount = uniquePixelIds.length;

        // Verify reservation belongs to THIS user and is not expired
        const reservation = await pool.query(
            'SELECT id FROM pixel_reservations WHERE id=$1 AND advertiser_id=$2 AND expires_at>NOW()',
            [reservationId, userId]
        );
        if (!reservation.rows.length) {
            return res.status(400).json({ error: 'Invalid or expired reservation' });
        }

        const bbox = await pool.query(
            'SELECT MIN(x) as min_x, MIN(y) as min_y, MAX(x) as max_x, MAX(y) as max_y FROM pixels WHERE id=ANY($1::bigint[])',
            [uniquePixelIds]
        );

        const adResult = await pool.query(`
            INSERT INTO advertisements
                (advertiser_id, advertiser_name, website_url, description,
                 pixel_count, pixel_ids, min_x, min_y, max_x, max_y, status)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'pending')
            RETURNING id
        `, [userId, advertiserName, websiteUrl, description||'', pixelCount, uniquePixelIds,
            bbox.rows[0].min_x, bbox.rows[0].min_y, bbox.rows[0].max_x, bbox.rows[0].max_y]);

        const advertisementId = adResult.rows[0].id;

        const session = await stripe.checkout.sessions.create({
            payment_method_types: ['card'],
            line_items: [{
                price_data: {
                    currency: 'usd',
                    product_data: { name: `${pixelCount.toLocaleString()} Pixels on Million Dollar Grid` },
                    unit_amount: pixelCount * 100,
                },
                quantity: 1,
            }],
            mode: 'payment',
            success_url: `${process.env.FRONTEND_URL}/payment/success?session_id={CHECKOUT_SESSION_ID}`,
            cancel_url:  `${process.env.FRONTEND_URL}/payment/cancel?reservation_id=${reservationId}`,
            metadata: { userId, advertisementId, reservationId, pixelCount: String(pixelCount) },
            expires_at: Math.floor(Date.now() / 1000) + 1800,
            customer_email: req.user.email,
        });

        await pool.query(`
            INSERT INTO payments
                (advertiser_id, advertisement_id, amount, pixel_count, status, payment_method, stripe_session_id, ip_address)
            VALUES ($1,$2,$3,$4,'pending','stripe',$5,$6)
        `, [userId, advertisementId, pixelCount, pixelCount, session.id, req.ip]);

        res.json({ sessionId: session.id, url: session.url, advertisementId });
    } catch (error) {
        logger.error('Stripe session error:', error.message);
        res.status(500).json({ error: 'Failed to create payment session' });
    }
});

// POST /api/payments/webhooks/stripe
router.post('/webhooks/stripe', express.raw({ type: 'application/json' }), async (req, res) => {
    let event;
    try {
        event = stripe.webhooks.constructEvent(
            req.body, req.headers['stripe-signature'], process.env.STRIPE_WEBHOOK_SECRET
        );
    } catch (err) {
        logger.warn('Stripe webhook verification failed:', err.message);
        return res.status(400).json({ error: 'Webhook Error' });
    }

    if (event.type === 'checkout.session.completed') {
        await handleSuccessfulPayment(event.data.object);
    }

    res.json({ received: true });
});

async function handleSuccessfulPayment(session) {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');

        const result = await client.query(`
            SELECT p.id, p.advertiser_id, p.advertisement_id, a.pixel_ids
            FROM payments p JOIN advertisements a ON p.advertisement_id=a.id
            WHERE p.stripe_session_id=$1 AND p.status='pending'
            FOR UPDATE
        `, [session.id]);

        if (!result.rows.length) { await client.query('ROLLBACK'); return; }

        const { id: paymentId, advertiser_id, advertisement_id, pixel_ids } = result.rows[0];
        const { reservationId } = session.metadata;

        // Atomic pixel purchase
        await client.query(`
            UPDATE pixels SET status='sold', advertiser_id=$1, advertisement_id=$2, sold_at=NOW(), price_paid=1.00
            WHERE id=ANY($3::bigint[])
        `, [advertiser_id, advertisement_id, pixel_ids]);

        await client.query(`
            UPDATE advertisements SET status='pending', is_active=false, updated_at=NOW() WHERE id=$1
        `, [advertisement_id]);

        await client.query(
            'UPDATE payments SET status=$1, completed_at=NOW(), stripe_charge_id=$2, amount=$3 WHERE id=$4',
            ['completed', session.payment_intent, session.amount_total/100, paymentId]
        );

        if (reservationId) {
            await client.query('DELETE FROM pixel_reservations WHERE id=$1', [reservationId]);
        }

        await client.query('COMMIT');
        broadcastPixelUpdate({ type: 'PIXELS_SOLD', pixelIds: pixel_ids, advertisementId: advertisement_id, timestamp: new Date().toISOString() });
        logger.info(`Payment completed: ${pixel_ids?.length} pixels`);
    } catch (error) {
        await client.query('ROLLBACK');
        logger.error('Payment processing error:', error.message);
    } finally {
        client.release();
    }
}

// POST /api/payments/upload-ad-image
router.post('/upload-ad-image', authenticate, validateImageUpload, async (req, res) => {
    try {
        if (!req.file) return res.status(400).json({ error: 'No image provided' });
        res.json({
            success: true,
            imageUrl: `/uploads/ads/${req.file.filename}`,
            width: req.file.processedWidth,
            height: req.file.processedHeight,
        });
    } catch { res.status(500).json({ error: 'Failed to upload image' }); }
});

module.exports = router;