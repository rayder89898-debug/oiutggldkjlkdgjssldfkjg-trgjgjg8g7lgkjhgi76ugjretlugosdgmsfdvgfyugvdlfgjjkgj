const express  = require('express');
const router   = express.Router();
const bcrypt   = require('bcrypt');
const jwt      = require('jsonwebtoken');
const crypto   = require('crypto');
const { body, validationResult } = require('express-validator');
const { pool } = require('../config/database');
const { authenticate } = require('../middleware/auth');
const logger   = require('../config/logger');

const SALT_ROUNDS = 12;

function generateToken(user) {
    return jwt.sign(
        { id: user.id, email: user.email, role: user.role },
        process.env.JWT_SECRET,
        { expiresIn: '7d', issuer: 'milliondollargrid.com', algorithm: 'HS256' }
    );
}

// POST /api/auth/register
router.post('/register', [
    body('email').isEmail().normalizeEmail().isLength({ max: 255 }),
    body('password')
        .isLength({ min: 8, max: 128 })
        .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])/)
        .withMessage('Password must have uppercase, lowercase, number and special char'),
    body('name').trim().isLength({ min: 1, max: 100 }).escape(),
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

        const { email, password, name } = req.body;

        const existing = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
        if (existing.rows.length) {
            return res.status(409).json({ error: 'An account with this email already exists' });
        }

        const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
        const verificationToken = crypto.randomBytes(32).toString('hex');

        // Role is ALWAYS 'advertiser' - enforced by DB DEFAULT
        const result = await pool.query(`
            INSERT INTO users (email, password_hash, name, verification_token, ip_address)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING id, email, name, role
        `, [email, passwordHash, name, verificationToken, req.ip]);

        const user = result.rows[0];
        logger.info('New user registered', { userId: user.id });

        res.status(201).json({
            message: 'Account created successfully',
            token: generateToken(user),
            user: { id: user.id, email: user.email, name: user.name, role: user.role },
        });
    } catch (error) {
        logger.error('Registration error:', error.message);
        res.status(500).json({ error: 'Registration failed' });
    }
});

// POST /api/auth/login
router.post('/login', [
    body('email').isEmail().normalizeEmail(),
    body('password').isLength({ min: 1, max: 128 }),
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) return res.status(400).json({ error: 'Invalid credentials' });

        const { email, password } = req.body;
        const result = await pool.query(
            'SELECT id, email, name, role, password_hash, is_banned, ban_reason FROM users WHERE email = $1',
            [email]
        );
        const user = result.rows[0];

        // Always run bcrypt - prevents timing attacks (user enumeration)
        const isValid = user
            ? await bcrypt.compare(password, user.password_hash)
            : await bcrypt.hash('timing_attack_prevention', 10).then(() => false);

        if (!user || !isValid) {
            logger.warn('Failed login', { ip: req.ip });
            return res.status(401).json({ error: 'Invalid email or password' });
        }
        if (user.is_banned) return res.status(403).json({ error: 'Account suspended' });

        await pool.query('UPDATE users SET last_login=NOW(), ip_address=$2 WHERE id=$1', [user.id, req.ip]);

        res.json({
            token: generateToken(user),
            user: { id: user.id, email: user.email, name: user.name, role: user.role },
        });
    } catch (error) {
        logger.error('Login error:', error.message);
        res.status(500).json({ error: 'Login failed' });
    }
});

// GET /api/auth/me
router.get('/me', authenticate, async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT id, email, name, role, is_verified, created_at FROM users WHERE id = $1',
            [req.user.id]
        );
        if (!result.rows.length) return res.status(404).json({ error: 'User not found' });
        res.json(result.rows[0]);
    } catch { res.status(500).json({ error: 'Failed to get profile' }); }
});

module.exports = router;