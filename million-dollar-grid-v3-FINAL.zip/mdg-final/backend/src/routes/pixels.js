const express = require('express');
const router  = express.Router();
const { body, query, validationResult } = require('express-validator');
const { authenticate } = require('../middleware/auth');
const { pool }  = require('../config/database');
const { broadcastPixelUpdate } = require('../services/websocketService');
const { getCacheClient } = require('../config/cache');
const logger = require('../config/logger');

// Click fraud prevention
const clickTracker = new Map();

// GET /api/pixels/grid
router.get('/grid', [
    query('chunkX').isInt({ min: 0, max: 99 }).optional(),
    query('chunkY').isInt({ min: 0, max: 9 }).optional(),
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

        const chunkX = parseInt(req.query.chunkX) || 0;
        const chunkY = parseInt(req.query.chunkY) || 0;
        const chunkSize = 100;

        const cacheKey = `grid_chunk_${chunkX}_${chunkY}`;
        const cache = getCacheClient();
        const cached = await cache.get(cacheKey);
        if (cached) { res.setHeader('X-Cache', 'HIT'); return res.json(JSON.parse(cached)); }

        const minX = chunkX * chunkSize + 1;
        const maxX = minX + chunkSize - 1;
        const minY = chunkY * chunkSize + 1;
        const maxY = minY + chunkSize - 1;

        const result = await pool.query(`
            SELECT p.id, p.x, p.y, p.status,
                   a.id AS ad_id, a.website_url, a.image_url,
                   a.advertiser_name, a.alt_text,
                   a.min_x, a.min_y, a.max_x, a.max_y
            FROM pixels p
            LEFT JOIN advertisements a ON p.advertisement_id = a.id
                AND a.is_active = true AND a.status = 'active'
            WHERE p.x BETWEEN $1 AND $2 AND p.y BETWEEN $3 AND $4
            ORDER BY p.y, p.x
        `, [minX, maxX, minY, maxY]);

        const response = { chunkX, chunkY, pixels: result.rows };
        await cache.setEx(cacheKey, 30, JSON.stringify(response));
        res.setHeader('X-Cache', 'MISS');
        res.json(response);
    } catch (error) {
        logger.error('Grid fetch error:', error.message);
        res.status(500).json({ error: 'Failed to fetch grid data' });
    }
});

// GET /api/pixels/available-count
router.get('/available-count', async (req, res) => {
    try {
        const cache = getCacheClient();
        const cached = await cache.get('pixel_stats');
        if (cached) return res.json(JSON.parse(cached));

        const result = await pool.query(`
            SELECT
                COUNT(*) FILTER (WHERE status='available') AS available,
                COUNT(*) FILTER (WHERE status='sold')      AS sold,
                COUNT(*) FILTER (WHERE status='reserved')  AS reserved,
                COUNT(*) AS total
            FROM pixels
        `);
        await cache.setEx('pixel_stats', 60, JSON.stringify(result.rows[0]));
        res.json(result.rows[0]);
    } catch { res.status(500).json({ error: 'Failed to get pixel stats' }); }
});

// GET /api/pixels/sold
router.get('/sold', async (req, res) => {
    try {
        const cache = getCacheClient();
        const cached = await cache.get('sold_ads_overlay');
        if (cached) return res.json(JSON.parse(cached));

        const result = await pool.query(`
            SELECT id, advertiser_name, website_url, image_url, alt_text,
                   min_x, min_y, max_x, max_y, pixel_count, click_count
            FROM advertisements
            WHERE is_active=true AND status='active'
            ORDER BY pixel_count DESC
        `);
        await cache.setEx('sold_ads_overlay', 60, JSON.stringify(result.rows));
        res.json(result.rows);
    } catch { res.status(500).json({ error: 'Failed to fetch sold pixels' }); }
});

// POST /api/pixels/reserve
router.post('/reserve', authenticate, [
    body('pixelIds').isArray({ min: 1, max: 10000 }),
    body('pixelIds.*').isInt({ min: 1, max: 10000000 }),
    body('sessionId').isUUID(),
], async (req, res) => {
    const client = await pool.connect();
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

        const { pixelIds, sessionId } = req.body;
        const userId = req.user.id;

        // Deduplicate pixelIds
        const uniquePixelIds = [...new Set(pixelIds)];

        await client.query('BEGIN');

        const check = await client.query(`
            SELECT id, status FROM pixels
            WHERE id = ANY($1::bigint[])
            FOR UPDATE SKIP LOCKED
        `, [uniquePixelIds]);

        const unavailable = check.rows.filter(r => r.status !== 'available');
        if (unavailable.length > 0 || check.rows.length !== uniquePixelIds.length) {
            await client.query('ROLLBACK');
            return res.status(409).json({
                error: 'Some pixels are no longer available',
                unavailableIds: unavailable.map(p => p.id),
            });
        }

        await client.query(
            'UPDATE pixels SET status=$1, reserved_at=NOW() WHERE id=ANY($2::bigint[])',
            ['reserved', uniquePixelIds]
        );

        const reservation = await client.query(`
            INSERT INTO pixel_reservations (pixel_ids, session_id, advertiser_id, expires_at)
            VALUES ($1, $2, $3, NOW() + INTERVAL '15 minutes')
            RETURNING id, expires_at
        `, [uniquePixelIds, sessionId, userId]);

        await client.query('COMMIT');

        broadcastPixelUpdate({ type: 'PIXELS_RESERVED', pixelIds: uniquePixelIds, timestamp: new Date().toISOString() });

        res.json({
            success: true,
            reservationId: reservation.rows[0].id,
            expiresAt: reservation.rows[0].expires_at,
            pixelCount: uniquePixelIds.length,
            totalCost: uniquePixelIds.length * 1.00,
        });
    } catch (error) {
        await client.query('ROLLBACK');
        logger.error('Pixel reservation error:', error.message);
        res.status(500).json({ error: 'Failed to reserve pixels' });
    } finally {
        client.release();
    }
});

// POST /api/pixels/release
router.post('/release', authenticate, [
    body('reservationId').isUUID(),
], async (req, res) => {
    const client = await pool.connect();
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

        const { reservationId } = req.body;
        await client.query('BEGIN');

        const reservation = await client.query(
            'SELECT pixel_ids FROM pixel_reservations WHERE id=$1 AND advertiser_id=$2',
            [reservationId, req.user.id]
        );
        if (!reservation.rows.length) {
            await client.query('ROLLBACK');
            return res.status(404).json({ error: 'Reservation not found' });
        }

        const pixelIds = reservation.rows[0].pixel_ids;
        await client.query(
            'UPDATE pixels SET status=$1, reserved_at=NULL WHERE id=ANY($2::bigint[]) AND status=$3',
            ['available', pixelIds, 'reserved']
        );
        await client.query('DELETE FROM pixel_reservations WHERE id=$1', [reservationId]);
        await client.query('COMMIT');

        broadcastPixelUpdate({ type: 'PIXELS_RELEASED', pixelIds, timestamp: new Date().toISOString() });
        res.json({ success: true });
    } catch (error) {
        await client.query('ROLLBACK');
        res.status(500).json({ error: 'Failed to release reservation' });
    } finally {
        client.release();
    }
});

// POST /api/pixels/:adId/click - With click fraud prevention
router.post('/:adId/click', async (req, res) => {
    try {
        const { adId } = req.params;
        // Strict UUID v4 validation
        if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(adId)) {
            return res.json({ success: true });
        }

        const ip = req.ip;
        const clickKey = `${ip}:${adId}`;
        const now = Date.now();
        const lastClick = clickTracker.get(clickKey);

        // 1 click per IP per ad per minute
        if (lastClick && (now - lastClick) < 60000) {
            return res.json({ success: true });
        }
        clickTracker.set(clickKey, now);

        // Cleanup old entries
        if (clickTracker.size > 1000) {
            for (const [k, ts] of clickTracker) {
                if (now - ts > 60000) clickTracker.delete(k);
            }
        }

        pool.query(
            'INSERT INTO ad_clicks (advertisement_id, visitor_ip, user_agent, referer) VALUES ($1,$2,$3,$4)',
            [adId, ip, (req.headers['user-agent'] || '').substring(0,500), (req.headers.referer || '').substring(0,500) || null]
        ).catch(() => {});

        pool.query('UPDATE advertisements SET click_count=click_count+1 WHERE id=$1', [adId]).catch(() => {});

        res.json({ success: true });
    } catch { res.json({ success: true }); }
});

module.exports = router;