const express = require('express');
const router  = express.Router();
const { body, param, validationResult } = require('express-validator');
const { authenticate, requireAdmin, adminSecurityCheck } = require('../middleware/auth');
const { pool }   = require('../config/database');
const { broadcastPixelUpdate } = require('../services/websocketService');
const logger = require('../config/logger');

// All admin routes: JWT + Admin role + IP/Header check
router.use(authenticate, requireAdmin, adminSecurityCheck);

const validateUUID = (name) => param(name).isUUID(4).withMessage('Invalid ID');
const ALLOWED_STATUSES = ['pending','active','rejected','suspended'];

// GET /api/<secret>/dashboard
router.get('/dashboard', async (req, res) => {
    try {
        const [stats, recentPayments, revenueByDay] = await Promise.all([
            pool.query(`SELECT
                (SELECT COUNT(*) FROM pixels WHERE status='sold') AS pixels_sold,
                (SELECT COUNT(*) FROM pixels WHERE status='available') AS pixels_available,
                (SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='completed') AS total_revenue,
                (SELECT COUNT(*) FROM advertisements WHERE status='pending') AS pending_reviews,
                (SELECT COUNT(*) FROM advertisements WHERE is_active=true) AS active_ads,
                (SELECT COALESCE(SUM(click_count),0) FROM advertisements) AS total_clicks,
                (SELECT COUNT(*) FROM users WHERE role='advertiser') AS total_advertisers,
                (SELECT COUNT(*) FROM payments WHERE status='completed' AND created_at>NOW()-INTERVAL '30 days') AS payments_last_30d
            `),
            pool.query(`SELECT p.id, p.amount, p.pixel_count, p.status, p.created_at,
                u.name, u.email, p.payment_method
                FROM payments p JOIN users u ON p.advertiser_id=u.id
                ORDER BY p.created_at DESC LIMIT 10`),
            pool.query(`SELECT DATE_TRUNC('day', completed_at) AS date, SUM(amount) AS revenue, COUNT(*) AS transactions
                FROM payments WHERE status='completed' AND completed_at>NOW()-INTERVAL '30 days'
                GROUP BY DATE_TRUNC('day', completed_at) ORDER BY date`),
        ]);
        res.json({ stats: stats.rows[0], recentPayments: recentPayments.rows, revenueByDay: revenueByDay.rows });
    } catch (error) {
        logger.error('Admin dashboard error:', error.message);
        res.status(500).json({ error: 'Failed to load dashboard' });
    }
});

// GET /api/<secret>/advertisements
router.get('/advertisements', async (req, res) => {
    try {
        const status = ALLOWED_STATUSES.includes(req.query.status) ? req.query.status :
                       req.query.status === 'all' ? 'all' : 'pending';
        const page  = Math.max(1, parseInt(req.query.page) || 1);
        const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 20));
        const offset = (page - 1) * limit;

        let query, params;
        if (status === 'all') {
            query = `SELECT a.id, a.advertiser_name, a.website_url, a.description,
                a.image_url, a.pixel_count, a.status, a.is_active, a.click_count,
                a.created_at, a.reviewed_at, a.rejection_reason,
                u.email AS advertiser_email,
                p.amount AS payment_amount, p.status AS payment_status, p.payment_method
                FROM advertisements a JOIN users u ON a.advertiser_id=u.id
                LEFT JOIN payments p ON p.advertisement_id=a.id AND p.status='completed'
                ORDER BY a.created_at DESC LIMIT $1 OFFSET $2`;
            params = [limit, offset];
        } else {
            query = `SELECT a.id, a.advertiser_name, a.website_url, a.description,
                a.image_url, a.pixel_count, a.status, a.is_active, a.click_count,
                a.created_at, a.reviewed_at, a.rejection_reason,
                u.email AS advertiser_email,
                p.amount AS payment_amount, p.status AS payment_status, p.payment_method
                FROM advertisements a JOIN users u ON a.advertiser_id=u.id
                LEFT JOIN payments p ON p.advertisement_id=a.id AND p.status='completed'
                WHERE a.status=$3
                ORDER BY a.created_at DESC LIMIT $1 OFFSET $2`;
            params = [limit, offset, status];
        }

        const [result, count] = await Promise.all([
            pool.query(query, params),
            status === 'all'
                ? pool.query('SELECT COUNT(*) FROM advertisements')
                : pool.query('SELECT COUNT(*) FROM advertisements WHERE status=$1', [status]),
        ]);

        res.json({ advertisements: result.rows, total: parseInt(count.rows[0].count), page });
    } catch { res.status(500).json({ error: 'Failed to fetch advertisements' }); }
});

// PATCH /api/<secret>/advertisements/:id/review
router.patch('/advertisements/:id/review', [
    validateUUID('id'),
    body('action').isIn(['approve','reject','suspend']),
    body('reason').trim().isLength({ max: 500 }).optional(),
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

        const { action, reason } = req.body;
        const statusMap = { approve: ['active',true], reject: ['rejected',false], suspend: ['suspended',false] };
        const [newStatus, isActive] = statusMap[action];

        const result = await pool.query(`
            UPDATE advertisements SET status=$1, is_active=$2, reviewed_by=$3,
            reviewed_at=NOW(), rejection_reason=$4, updated_at=NOW()
            WHERE id=$5 RETURNING id
        `, [newStatus, isActive, req.user.id, reason||null, req.params.id]);

        if (!result.rows.length) return res.status(404).json({ error: 'Not found' });

        await pool.query(
            'INSERT INTO audit_log (user_id, action, entity_type, entity_id, new_values, ip_address) VALUES ($1,$2,$3,$4,$5,$6)',
            [req.user.id, `ad_${action}`, 'advertisement', req.params.id, JSON.stringify({ status: newStatus, reason }), req.ip]
        );

        broadcastPixelUpdate({ type: 'AD_STATUS_CHANGED', advertisementId: req.params.id, status: newStatus, timestamp: new Date().toISOString() });
        res.json({ success: true, status: newStatus });
    } catch { res.status(500).json({ error: 'Failed to review advertisement' }); }
});

// DELETE /api/<secret>/advertisements/:id
router.delete('/advertisements/:id', [validateUUID('id')], async (req, res) => {
    const client = await pool.connect();
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

        await client.query('BEGIN');
        const ad = await client.query('SELECT pixel_ids FROM advertisements WHERE id=$1', [req.params.id]);
        if (!ad.rows.length) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'Not found' }); }

        const pixelIds = ad.rows[0].pixel_ids || [];
        if (pixelIds.length) {
            await client.query(
                'UPDATE pixels SET status=$1, advertiser_id=NULL, advertisement_id=NULL, sold_at=NULL WHERE id=ANY($2::bigint[])',
                ['available', pixelIds]
            );
        }
        await client.query('DELETE FROM advertisements WHERE id=$1', [req.params.id]);
        await client.query('COMMIT');

        broadcastPixelUpdate({ type: 'AD_DELETED', pixelIds, timestamp: new Date().toISOString() });
        res.json({ success: true });
    } catch (error) {
        await client.query('ROLLBACK');
        res.status(500).json({ error: 'Failed to delete' });
    } finally { client.release(); }
});

// GET /api/<secret>/payments
router.get('/payments', async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT p.id, p.amount, p.pixel_count, p.status, p.created_at,
                   p.payment_method, p.completed_at,
                   u.name, u.email, a.advertiser_name, a.website_url
            FROM payments p JOIN users u ON p.advertiser_id=u.id
            LEFT JOIN advertisements a ON p.advertisement_id=a.id
            ORDER BY p.created_at DESC LIMIT 100
        `);
        res.json(result.rows);
    } catch { res.status(500).json({ error: 'Failed to fetch payments' }); }
});

// GET /api/<secret>/stats/detailed
router.get('/stats/detailed', async (req, res) => {
    try {
        const [topAds, paymentMethods] = await Promise.all([
            pool.query('SELECT id, advertiser_name, website_url, click_count, pixel_count FROM advertisements WHERE is_active=true ORDER BY click_count DESC LIMIT 10'),
            pool.query("SELECT payment_method, COUNT(*) as count, SUM(amount) as total FROM payments WHERE status='completed' GROUP BY payment_method"),
        ]);
        res.json({ topAds: topAds.rows, paymentMethods: paymentMethods.rows });
    } catch { res.status(500).json({ error: 'Failed to fetch stats' }); }
});

// GET /api/<secret>/users
router.get('/users', async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT id, email, name, role, is_verified, is_banned, created_at, last_login,
                   (SELECT COUNT(*) FROM advertisements WHERE advertiser_id=users.id) AS ad_count,
                   (SELECT COALESCE(SUM(amount),0) FROM payments WHERE advertiser_id=users.id AND status='completed') AS total_spent
            FROM users ORDER BY created_at DESC LIMIT 100
        `);
        res.json(result.rows);
    } catch { res.status(500).json({ error: 'Failed to fetch users' }); }
});

// PATCH /api/<secret>/users/:id/ban
router.patch('/users/:id/ban', [
    validateUUID('id'),
    body('banned').isBoolean(),
    body('reason').trim().isLength({ max: 500 }).optional(),
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
        const { banned, reason } = req.body;
        await pool.query('UPDATE users SET is_banned=$1, ban_reason=$2 WHERE id=$3', [banned, reason||null, req.params.id]);
        res.json({ success: true });
    } catch { res.status(500).json({ error: 'Failed to update user' }); }
});

module.exports = router;