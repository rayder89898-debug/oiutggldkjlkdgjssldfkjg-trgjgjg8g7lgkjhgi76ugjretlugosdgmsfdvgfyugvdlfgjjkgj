CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255),
    name VARCHAR(255),
    role VARCHAR(20) DEFAULT 'advertiser' CHECK (role IN ('advertiser', 'admin', 'superadmin')),
    is_verified BOOLEAN DEFAULT false,
    verification_token VARCHAR(255),
    reset_token VARCHAR(255),
    reset_token_expires TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    last_login TIMESTAMPTZ,
    ip_address INET,
    is_banned BOOLEAN DEFAULT false,
    ban_reason TEXT
);
CREATE INDEX idx_users_email ON users(email);

CREATE TABLE pixels (
    id BIGINT PRIMARY KEY,
    x INTEGER NOT NULL CHECK (x >= 1 AND x <= 10000),
    y INTEGER NOT NULL CHECK (y >= 1 AND y <= 1000),
    status VARCHAR(20) DEFAULT 'available' CHECK (status IN ('available', 'reserved', 'sold', 'pending')),
    advertiser_id UUID REFERENCES users(id) ON DELETE SET NULL,
    advertisement_id UUID,
    reserved_at TIMESTAMPTZ,
    sold_at TIMESTAMPTZ,
    price_paid DECIMAL(10,2),
    CONSTRAINT pixels_coords_unique UNIQUE (x, y)
);
CREATE INDEX idx_pixels_status ON pixels(status);
CREATE INDEX idx_pixels_advertiser ON pixels(advertiser_id);
CREATE INDEX idx_pixels_coords ON pixels(x, y);

CREATE TABLE advertisements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    advertiser_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    advertiser_name VARCHAR(255) NOT NULL,
    website_url TEXT NOT NULL,
    description TEXT,
    image_url TEXT,
    image_path TEXT,
    alt_text VARCHAR(255),
    pixel_count INTEGER NOT NULL DEFAULT 0,
    pixel_ids BIGINT[],
    min_x INTEGER, min_y INTEGER, max_x INTEGER, max_y INTEGER,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','active','expired','suspended')),
    rejection_reason TEXT,
    reviewed_by UUID REFERENCES users(id),
    reviewed_at TIMESTAMPTZ,
    is_active BOOLEAN DEFAULT false,
    click_count BIGINT DEFAULT 0,
    impression_count BIGINT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    is_nsfw BOOLEAN DEFAULT false,
    is_flagged BOOLEAN DEFAULT false,
    flag_reason TEXT
);
CREATE INDEX idx_ads_advertiser ON advertisements(advertiser_id);
CREATE INDEX idx_ads_status ON advertisements(status);
CREATE INDEX idx_ads_active ON advertisements(is_active);

CREATE TABLE payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    advertiser_id UUID NOT NULL REFERENCES users(id),
    advertisement_id UUID REFERENCES advertisements(id),
    amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(10) DEFAULT 'USD',
    pixel_count INTEGER NOT NULL,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending','processing','completed','failed','refunded','cancelled')),
    payment_method VARCHAR(30),
    stripe_payment_intent_id VARCHAR(255),
    stripe_session_id VARCHAR(255),
    stripe_charge_id VARCHAR(255),
    paypal_order_id VARCHAR(255),
    paypal_capture_id VARCHAR(255),
    ip_address INET,
    user_agent TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);
CREATE INDEX idx_payments_advertiser ON payments(advertiser_id);
CREATE INDEX idx_payments_status ON payments(status);

CREATE TABLE ad_clicks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    advertisement_id UUID NOT NULL REFERENCES advertisements(id) ON DELETE CASCADE,
    pixel_id BIGINT,
    visitor_ip INET,
    user_agent TEXT,
    referer TEXT,
    clicked_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_clicks_ad ON ad_clicks(advertisement_id);
CREATE INDEX idx_clicks_time ON ad_clicks(clicked_at);

CREATE TABLE pixel_reservations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pixel_ids BIGINT[] NOT NULL,
    session_id VARCHAR(255) NOT NULL,
    advertiser_id UUID REFERENCES users(id),
    expires_at TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '15 minutes'),
    created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_reservations_expires ON pixel_reservations(expires_at);

CREATE TABLE audit_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50),
    entity_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;

CREATE TRIGGER ads_updated_at BEFORE UPDATE ON advertisements FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER payments_updated_at BEFORE UPDATE ON payments FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Default superadmin (CHANGE PASSWORD IMMEDIATELY)
INSERT INTO users (email, password_hash, name, role, is_verified)
VALUES ('admin@milliondollargrid.com', crypt('ChangeThisPassword123!', gen_salt('bf', 12)), 'Super Admin', 'superadmin', true);

-- Test pixels
INSERT INTO pixels (id, x, y)
SELECT gs, ((gs-1) % 10000)+1, CEIL(gs::float/10000)::INT
FROM generate_series(1, 100000) gs;