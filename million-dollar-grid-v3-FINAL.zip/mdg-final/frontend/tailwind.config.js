module.exports = {
  content: ['./src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: { display: ['"Bebas Neue"','sans-serif'], body: ['"DM Sans"','sans-serif'] },
      colors: { gold: { 400: '#fbbf24', 500: '#f59e0b' } },
      boxShadow: { gold: '0 0 20px rgba(245,158,11,0.3)' },
    },
  },
  plugins: [],
};