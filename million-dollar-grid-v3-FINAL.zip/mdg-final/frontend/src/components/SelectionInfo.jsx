import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
export default function SelectionInfo({ count, onClear }) {
  return (
    <motion.div initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} exit={{opacity:0,y:20}}
      className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 bg-gray-900 border border-yellow-500/40 rounded-2xl px-5 py-3 flex items-center gap-4 backdrop-blur-sm" style={{boxShadow:'0 0 20px rgba(245,158,11,0.2)'}}>
      <div>
        <p className="text-white text-sm font-semibold"><span className="text-yellow-400 font-black text-lg">{count.toLocaleString()}</span> pixels selected</p>
        <p className="text-gray-400 text-xs">Total: <span className="text-green-400 font-semibold">${count.toLocaleString()}</span></p>
      </div>
      <div className="flex gap-2">
        <button onClick={onClear} className="px-3 py-1.5 text-xs border border-gray-700 text-gray-400 rounded-lg hover:border-gray-500">Clear</button>
        <Link to="/purchase" className="px-4 py-1.5 text-xs bg-gradient-to-r from-yellow-500 to-amber-500 text-black font-bold rounded-lg hover:from-yellow-400">Advertise →</Link>
      </div>
    </motion.div>
  );
}