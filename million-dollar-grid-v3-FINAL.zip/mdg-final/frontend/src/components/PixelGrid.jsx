import React, { useRef, useCallback, useEffect, useState, useMemo } from 'react';
import { usePixelStore } from '../store/pixelStore';
import AdTooltip from './AdTooltip';
import SelectionInfo from './SelectionInfo';

const GRID_WIDTH=10000, GRID_HEIGHT=1000, PIXEL_SIZE=8, CHUNK_SIZE=100;

export default function PixelGrid() {
  const containerRef=useRef(null), canvasRef=useRef(null);
  const [zoom,setZoom]=useState(1), [hoveredAd,setHoveredAd]=useState(null);
  const [tooltipPos,setTooltipPos]=useState({x:0,y:0});
  const [isDragging,setIsDragging]=useState(false), [dragStart,setDragStart]=useState(null);
  const [viewOffset,setViewOffset]=useState({x:0,y:0});
  const {soldAds,selectedPixels,togglePixel,selectRect,clearSelection,loadChunk,loadedChunks}=usePixelStore();
  const pixelSize=PIXEL_SIZE*zoom, totalWidth=GRID_WIDTH*pixelSize, totalHeight=GRID_HEIGHT*pixelSize;

  const visibleChunks=useMemo(()=>{
    if(!containerRef.current) return [];
    const {scrollLeft,scrollTop,clientWidth,clientHeight}=containerRef.current;
    const chunks=[];
    const sX=Math.max(0,Math.floor(scrollLeft/(CHUNK_SIZE*pixelSize))-1);
    const eX=Math.min(99,Math.ceil((scrollLeft+clientWidth)/(CHUNK_SIZE*pixelSize))+1);
    const sY=Math.max(0,Math.floor(scrollTop/(CHUNK_SIZE*pixelSize))-1);
    const eY=Math.min(9,Math.ceil((scrollTop+clientHeight)/(CHUNK_SIZE*pixelSize))+1);
    for(let cy=sY;cy<=eY;cy++) for(let cx=sX;cx<=eX;cx++) chunks.push({cx,cy});
    return chunks;
  },[viewOffset,pixelSize]);

  useEffect(()=>{ visibleChunks.forEach(({cx,cy})=>{ if(!loadedChunks.has(`${cx}-${cy}`)) loadChunk(cx,cy); }); },[visibleChunks,loadChunk,loadedChunks]);

  useEffect(()=>{
    const canvas=canvasRef.current; if(!canvas) return;
    const ctx=canvas.getContext('2d');
    canvas.width=Math.min(totalWidth,16384); canvas.height=Math.min(totalHeight,16384);
    ctx.fillStyle='#030712'; ctx.fillRect(0,0,canvas.width,canvas.height);
    if(pixelSize>=4){ctx.strokeStyle='rgba(255,255,255,0.04)';ctx.lineWidth=0.5;for(let x=0;x<GRID_WIDTH;x+=10){ctx.beginPath();ctx.moveTo(x*pixelSize,0);ctx.lineTo(x*pixelSize,canvas.height);ctx.stroke();}}
    soldAds.forEach(ad=>{if(!ad.image_url){ctx.fillStyle=`hsl(${ad.id.charCodeAt(0)*7%360},60%,40%)`;ctx.fillRect((ad.min_x-1)*pixelSize,(ad.min_y-1)*pixelSize,(ad.max_x-ad.min_x+1)*pixelSize,(ad.max_y-ad.min_y+1)*pixelSize);}});
    ctx.fillStyle='rgba(245,158,11,0.45)';
    selectedPixels.forEach(id=>{const x=(id-1)%GRID_WIDTH,y=Math.floor((id-1)/GRID_WIDTH);ctx.fillRect(x*pixelSize,y*pixelSize,pixelSize,pixelSize);});
  },[soldAds,selectedPixels,pixelSize,totalWidth,totalHeight]);

  const getPixel=useCallback((e)=>{
    const rect=canvasRef.current.getBoundingClientRect();
    return {x:Math.max(1,Math.min(GRID_WIDTH,Math.floor((e.clientX-rect.left)/pixelSize)+1)),y:Math.max(1,Math.min(GRID_HEIGHT,Math.floor((e.clientY-rect.top)/pixelSize)+1))};
  },[pixelSize]);

  const handleMouseDown=useCallback((e)=>{if(e.button!==0)return;const p=getPixel(e);setIsDragging(true);setDragStart(p);},[getPixel]);
  const handleMouseMove=useCallback((e)=>{const p=getPixel(e);setHoveredAd(soldAds.find(a=>p.x>=a.min_x&&p.x<=a.max_x&&p.y>=a.min_y&&p.y<=a.max_y)||null);setTooltipPos({x:e.clientX+15,y:e.clientY+15});},[getPixel,soldAds]);
  const handleMouseUp=useCallback((e)=>{
    if(!isDragging||!dragStart)return;setIsDragging(false);
    const p=getPixel(e);
    if(dragStart.x===p.x&&dragStart.y===p.y){
      const ad=soldAds.find(a=>p.x>=a.min_x&&p.x<=a.max_x&&p.y>=a.min_y&&p.y<=a.max_y);
      if(ad){fetch(`/api/pixels/${ad.id}/click`,{method:'POST',headers:{'Content-Type':'application/json'}}).catch(()=>{});window.open(ad.website_url,'_blank','noopener,noreferrer');}
      else togglePixel((p.y-1)*GRID_WIDTH+p.x);
    } else selectRect(Math.min(dragStart.x,p.x),Math.min(dragStart.y,p.y),Math.max(dragStart.x,p.x),Math.max(dragStart.y,p.y));
    setDragStart(null);
  },[isDragging,dragStart,getPixel,soldAds,togglePixel,selectRect]);

  return (
    <div className="relative w-full">
      <div className="absolute top-4 right-4 z-20 flex flex-col gap-1">
        {[['+',0.5],[`${Math.round(zoom*100)}%`,0],['-',-0.5],['↺',null]].map(([l,d],i)=>(
          <button key={i} onClick={()=>d!==null?setZoom(z=>Math.max(0.1,Math.min(8,z+d))):setZoom(1)}
            className="w-10 h-8 bg-gray-900 border border-gray-700 text-gray-400 rounded text-sm hover:bg-gray-800 transition-all">{l}</button>
        ))}
      </div>
      <div ref={containerRef} className="w-full overflow-auto bg-gray-950 rounded-xl border border-gray-800"
        style={{height:'70vh',cursor:hoveredAd?'pointer':'crosshair'}}
        onScroll={()=>containerRef.current&&setViewOffset({x:containerRef.current.scrollLeft,y:containerRef.current.scrollTop})}
        onWheel={(e)=>{if(e.ctrlKey||e.metaKey){e.preventDefault();setZoom(z=>Math.max(0.1,Math.min(8,z+(e.deltaY<0?0.2:-0.2))));}}}> 
        <div style={{width:totalWidth,height:totalHeight,position:'relative',minWidth:'100%'}}>
          <canvas ref={canvasRef} onMouseDown={handleMouseDown} onMouseMove={handleMouseMove} onMouseUp={handleMouseUp} onMouseLeave={()=>{setIsDragging(false);setHoveredAd(null);}} style={{display:'block',imageRendering:'pixelated'}}/>
          {soldAds.filter(a=>a.image_url).map(ad=>(
            <img key={ad.id} src={ad.image_url} alt={ad.alt_text||ad.advertiser_name} loading="lazy"
              style={{position:'absolute',left:(ad.min_x-1)*pixelSize,top:(ad.min_y-1)*pixelSize,width:(ad.max_x-ad.min_x+1)*pixelSize,height:(ad.max_y-ad.min_y+1)*pixelSize,imageRendering:pixelSize<2?'auto':'pixelated',pointerEvents:'none'}}/>
          ))}
        </div>
      </div>
      {hoveredAd&&<AdTooltip ad={hoveredAd} position={tooltipPos}/>}
      {selectedPixels.size>0&&<SelectionInfo count={selectedPixels.size} onClear={clearSelection}/>}
    </div>
  );
}