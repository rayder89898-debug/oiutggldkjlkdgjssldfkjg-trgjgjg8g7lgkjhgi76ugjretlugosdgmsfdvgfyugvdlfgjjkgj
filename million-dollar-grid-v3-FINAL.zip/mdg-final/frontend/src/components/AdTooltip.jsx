import React from 'react';
import { createPortal } from 'react-dom';
import { motion } from 'framer-motion';
export default function AdTooltip({ ad, position }) {
  if (!ad) return null;
  return createPortal(
    <motion.div initial={{opacity:0,scale:0.92}} animate={{opacity:1,scale:1}} transition={{duration:0.1}}
      className="fixed z-[9999] pointer-events-none"
      style={{left:Math.min(position.x,window.innerWidth-260), top:Math.min(position.y,window.innerHeight-120)}}>
      <div className="bg-gray-900 border border-yellow-500/30 rounded-xl shadow-2xl p-3 max-w-xs">
        <div className="flex items-start gap-3">
          {ad.image_url && <img src={ad.image_url} alt={ad.alt_text||ad.advertiser_name} className="w-12 h-12 rounded-lg object-cover bg-gray-800 flex-shrink-0" onError={e=>e.target.style.display='none'} />}
          <div className="min-w-0">
            <p className="text-white font-semibold text-sm truncate">{ad.advertiser_name}</p>
            <p className="text-yellow-400 text-xs truncate">{ad.website_url}</p>
            <div className="flex gap-2 mt-1 text-xs text-gray-500">
              <span>🟩 {ad.pixel_count?.toLocaleString()} px</span>
              <span>👆 {ad.click_count?.toLocaleString()}</span>
            </div>
          </div>
        </div>
        <p className="text-xs text-gray-600 mt-2 text-center">Click to visit →</p>
      </div>
    </motion.div>,
    document.body
  );
}