import React, { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuthStore } from '../store/authStore';
import { usePixelStore } from '../store/pixelStore';
import { useWebSocket } from '../hooks/useWebSocket';

export default function Navbar() {
  const { isAuthenticated, user, logout, isAdmin, getAdminPath } = useAuthStore();
  const { selectedPixels } = usePixelStore();
  const { isConnected } = useWebSocket();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const count = selectedPixels.size;
  const adminPath = getAdminPath();

  return (
    <header className="sticky top-0 z-50 glass border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between gap-4">
        <Link to="/" className="flex items-center gap-2 shrink-0" onClick={() => setOpen(false)}>
          <span className="text-2xl font-display bg-gradient-to-r from-yellow-400 to-amber-500 bg-clip-text text-transparent tracking-wider">MDG</span>
          <span className="hidden sm:block text-xs text-gray-500 border-l border-gray-700 pl-2 leading-tight">Million<br/>Dollar Grid</span>
        </Link>
        <nav className="hidden md:flex items-center gap-1 text-sm">
          {[['/', 'Grid', true],['/advertised','Advertisers'],['/top-ads','Top Ads'],['/terms','Terms']].map(([to,label,end]) => (
            <NavLink key={to} to={to} end={!!end} className={({isActive}) => `px-3 py-1.5 rounded-lg text-sm transition-all ${isActive?'text-white bg-gray-800':'text-gray-400 hover:text-white hover:bg-gray-800/60'}`}>{label}</NavLink>
          ))}
          {isAdmin() && <NavLink to={`/${adminPath}`} className={({isActive}) => `px-3 py-1.5 rounded-lg text-sm transition-all ${isActive?'text-yellow-400 bg-yellow-500/10':'text-yellow-500 hover:bg-yellow-500/10'}`}>⚙ Admin</NavLink>}
        </nav>
        <div className="flex items-center gap-3">
          <div className={`hidden sm:block w-2 h-2 rounded-full ${isConnected?'bg-green-500 animate-pulse':'bg-red-500'}`} title={isConnected?'Live':'Disconnected'} />
          {count > 0 && (
            <Link to="/purchase" className="hidden sm:flex items-center gap-1.5 px-3 py-1 bg-yellow-500/10 border border-yellow-500/30 rounded-full text-yellow-400 text-xs font-semibold hover:bg-yellow-500/20 transition-all">
              <span className="w-1.5 h-1.5 rounded-full bg-yellow-400" />{count.toLocaleString()} px · ${count.toLocaleString()}
            </Link>
          )}
          {isAuthenticated ? (
            <div className="relative">
              <button onClick={() => setOpen(o => !o)} className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-gray-700 hover:border-gray-500 transition-all text-sm">
                <span className="w-6 h-6 rounded-full bg-yellow-500 text-black font-bold flex items-center justify-center text-xs">{user?.name?.[0]?.toUpperCase()||'U'}</span>
                <span className="hidden sm:block text-gray-300 max-w-24 truncate">{user?.name}</span>
              </button>
              <AnimatePresence>
                {open && (
                  <motion.div initial={{opacity:0,y:-8}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-8}} transition={{duration:0.15}}
                    className="absolute right-0 mt-2 w-48 bg-gray-900 border border-gray-700 rounded-xl shadow-xl overflow-hidden z-50">
                    <div className="px-4 py-3 border-b border-gray-800">
                      <p className="text-white text-sm font-semibold truncate">{user?.name}</p>
                      <p className="text-gray-500 text-xs truncate">{user?.email}</p>
                    </div>
                    {isAdmin() && <Link to={`/${adminPath}`} onClick={() => setOpen(false)} className="block px-4 py-2.5 text-sm text-gray-300 hover:bg-gray-800">⚙ Admin</Link>}
                    <button onClick={() => { logout(); navigate('/'); setOpen(false); }} className="w-full text-left px-4 py-2.5 text-sm text-red-400 hover:bg-red-500/10">→ Logout</button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Link to="/login" className="text-sm text-gray-400 hover:text-white px-3 py-1.5">Login</Link>
              <Link to="/register" className="btn-primary text-sm py-1.5 px-4">Get Started</Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}