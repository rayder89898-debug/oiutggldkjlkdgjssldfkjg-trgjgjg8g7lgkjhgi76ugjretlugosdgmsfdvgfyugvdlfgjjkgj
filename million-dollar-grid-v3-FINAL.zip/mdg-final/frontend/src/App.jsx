import React, { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from 'react-query';
import { Toaster } from 'react-hot-toast';
import Layout from './components/Layout';
import { useAuthStore } from './store/authStore';

const HomePage       = lazy(() => import('./pages/HomePage'));
const PurchasePage   = lazy(() => import('./pages/PurchasePage'));
const PaymentSuccess = lazy(() => import('./pages/PaymentSuccess'));
const PaymentCancel  = lazy(() => import('./pages/PaymentCancel'));
const AdvertisedPage = lazy(() => import('./pages/AdvertisedPage'));
const TopAdsPage     = lazy(() => import('./pages/TopAdsPage'));
const TermsPage      = lazy(() => import('./pages/TermsPage'));
const LoginPage      = lazy(() => import('./pages/LoginPage'));
const RegisterPage   = lazy(() => import('./pages/RegisterPage'));
const AdminDashboard = lazy(() => import('./pages/admin/Dashboard'));
const AdminAds       = lazy(() => import('./pages/admin/Advertisements'));
const AdminPayments  = lazy(() => import('./pages/admin/Payments'));
const AdminStats     = lazy(() => import('./pages/admin/Stats'));
const AdminUsers     = lazy(() => import('./pages/admin/Users'));
const NotFound       = lazy(() => import('./pages/NotFound'));

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 2, staleTime: 30000, refetchOnWindowFocus: false } }
});

const Loading = () => (
  <div className="fixed inset-0 bg-gray-950 flex items-center justify-center">
    <div className="flex gap-1">{[0,1,2,3].map(i => <div key={i} className="w-2 h-6 bg-yellow-500 rounded-full animate-pulse" style={{ animationDelay: `${i*150}ms` }} />)}</div>
  </div>
);

const ProtectedRoute = ({ children, requireAdmin = false }) => {
  const { user, isAuthenticated } = useAuthStore();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (requireAdmin && !['admin','superadmin'].includes(user?.role)) return <Navigate to="/" replace />;
  return children;
};

// Admin path is secret - read from env
const ADMIN_PATH = process.env.REACT_APP_ADMIN_PATH || 'admin';

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Suspense fallback={<Loading />}>
          <Routes>
            <Route path="/" element={<Layout />}>
              <Route index element={<HomePage />} />
              <Route path="advertised" element={<AdvertisedPage />} />
              <Route path="top-ads" element={<TopAdsPage />} />
              <Route path="terms" element={<TermsPage />} />
              <Route path="login" element={<LoginPage />} />
              <Route path="register" element={<RegisterPage />} />
              <Route path="purchase" element={<ProtectedRoute><PurchasePage /></ProtectedRoute>} />
              <Route path="payment/success" element={<ProtectedRoute><PaymentSuccess /></ProtectedRoute>} />
              <Route path="payment/cancel" element={<ProtectedRoute><PaymentCancel /></ProtectedRoute>} />
              <Route path={ADMIN_PATH} element={<ProtectedRoute requireAdmin><AdminDashboard /></ProtectedRoute>} />
              <Route path={`${ADMIN_PATH}/advertisements`} element={<ProtectedRoute requireAdmin><AdminAds /></ProtectedRoute>} />
              <Route path={`${ADMIN_PATH}/payments`} element={<ProtectedRoute requireAdmin><AdminPayments /></ProtectedRoute>} />
              <Route path={`${ADMIN_PATH}/stats`} element={<ProtectedRoute requireAdmin><AdminStats /></ProtectedRoute>} />
              <Route path={`${ADMIN_PATH}/users`} element={<ProtectedRoute requireAdmin><AdminUsers /></ProtectedRoute>} />
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
        </Suspense>
        <Toaster position="top-right" toastOptions={{
          style: { background:'#111827', color:'#fff', border:'1px solid #f59e0b', borderRadius:'8px' }
        }} />
      </BrowserRouter>
    </QueryClientProvider>
  );
}