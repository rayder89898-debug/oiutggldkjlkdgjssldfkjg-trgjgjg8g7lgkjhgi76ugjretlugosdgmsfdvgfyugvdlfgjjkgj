import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import api from '../utils/api';

export const useAuthStore = create(
  persist(
    (set, get) => ({
      user: null, token: null, isAuthenticated: false, isLoading: false,

      login: async (email, password) => {
        set({ isLoading: true });
        try {
          const { data } = await api.post('/auth/login', { email, password });
          localStorage.setItem('mdg_token', data.token);
          set({ user: data.user, token: data.token, isAuthenticated: true, isLoading: false });
          return { success: true };
        } catch (e) {
          set({ isLoading: false });
          return { success: false, error: e.response?.data?.error || 'Login failed' };
        }
      },

      register: async (name, email, password) => {
        set({ isLoading: true });
        try {
          const { data } = await api.post('/auth/register', { name, email, password });
          localStorage.setItem('mdg_token', data.token);
          set({ user: data.user, token: data.token, isAuthenticated: true, isLoading: false });
          return { success: true };
        } catch (e) {
          set({ isLoading: false });
          return { success: false, error: e.response?.data?.error || 'Registration failed' };
        }
      },

      logout: () => { localStorage.removeItem('mdg_token'); set({ user: null, token: null, isAuthenticated: false }); },
      isAdmin: () => ['admin','superadmin'].includes(get().user?.role),
      getAdminPath: () => process.env.REACT_APP_ADMIN_PATH || 'admin',
    }),
    {
      name: 'mdg_auth',
      partialize: (s) => ({ user: s.user, token: s.token, isAuthenticated: s.isAuthenticated }),
    }
  )
);