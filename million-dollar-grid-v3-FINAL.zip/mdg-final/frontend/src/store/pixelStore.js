import { create } from 'zustand';
import api from '../utils/api';

const GRID_WIDTH = 10000;
const MAX_SELECTION = 10000;

export const usePixelStore = create((set, get) => ({
  soldAds: [], loadedChunks: new Map(), loadingChunks: new Set(),
  selectedPixels: new Set(), pixelStatus: new Map(),

  fetchSoldAds: async () => {
    try { const { data } = await api.get('/pixels/sold'); set({ soldAds: data }); } catch {}
  },

  loadChunk: async (cx, cy) => {
    const key = `${cx}-${cy}`;
    const { loadingChunks, loadedChunks } = get();
    if (loadedChunks.has(key) || loadingChunks.has(key)) return;
    set(s => ({ loadingChunks: new Set([...s.loadingChunks, key]) }));
    try {
      const { data } = await api.get(`/pixels/grid?chunkX=${cx}&chunkY=${cy}`);
      const ns = new Map(get().pixelStatus);
      data.pixels.forEach(p => ns.set(p.id, p.status));
      set(s => { const c = new Map(s.loadedChunks); c.set(key, data); const l = new Set(s.loadingChunks); l.delete(key); return { loadedChunks: c, loadingChunks: l, pixelStatus: ns }; });
    } catch { set(s => { const l = new Set(s.loadingChunks); l.delete(key); return { loadingChunks: l }; }); }
  },

  togglePixel: (id) => {
    if (get().pixelStatus.get(id) === 'sold') return;
    const s = new Set(get().selectedPixels);
    if (s.has(id)) s.delete(id); else if (s.size < MAX_SELECTION) s.add(id);
    set({ selectedPixels: s });
  },

  selectRect: (minX, minY, maxX, maxY) => {
    const { pixelStatus } = get();
    const s = new Set(get().selectedPixels);
    for (let y = minY; y <= maxY; y++) for (let x = minX; x <= maxX; x++) {
      const id = (y-1)*GRID_WIDTH+x;
      if (pixelStatus.get(id) !== 'sold' && s.size < MAX_SELECTION) s.add(id);
    }
    set({ selectedPixels: s });
  },

  clearSelection: () => set({ selectedPixels: new Set() }),

  updatePixelStatuses: (pixelIds, status) => {
    const ns = new Map(get().pixelStatus);
    pixelIds.forEach(id => ns.set(id, status));
    if (status === 'sold') {
      const sel = new Set(get().selectedPixels);
      pixelIds.forEach(id => sel.delete(id));
      set({ pixelStatus: ns, selectedPixels: sel });
    } else set({ pixelStatus: ns });
  },

  invalidateChunks: (pixelIds) => {
    if (!pixelIds?.length) return;
    const keys = new Set();
    pixelIds.forEach(id => { const x=((id-1)%GRID_WIDTH)+1; const y=Math.ceil(id/GRID_WIDTH); keys.add(`${Math.floor((x-1)/100)}-${Math.floor((y-1)/100)}`); });
    set(s => { const c = new Map(s.loadedChunks); keys.forEach(k => c.delete(k)); return { loadedChunks: c }; });
    keys.forEach(k => { const [cx,cy]=k.split('-').map(Number); get().loadChunk(cx,cy); });
    get().fetchSoldAds();
  },
}));