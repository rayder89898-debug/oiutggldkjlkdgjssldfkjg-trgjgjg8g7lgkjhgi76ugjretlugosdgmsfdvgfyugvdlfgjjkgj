import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { useAuthStore } from '../store/authStore';

const pw_strength = (pw) => { let s=0; if(pw.length>=8)s++; if(/[A-Z]/.test(pw))s++; if(/[0-9]/.test(pw))s++; if(/[^A-Za-z0-9]/.test(pw))s++; return s; };

export default function RegisterPage() {
  const navigate = useNavigate();
  const { register, isLoading } = useAuthStore();
  const [form, setForm] = useState({ name:'', email:'', password:'', confirm:'' });
  const [errors, setErrors] = useState({});
  const [agreed, setAgreed] = useState(false);
  const s = pw_strength(form.password);
  const colors=['','bg-red-500','bg-orange-500','bg-yellow-500','bg-green-500'];
  const labels=['','Weak','Fair','Good','Strong'];

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = 'Required';
    if (!form.email) e.email = 'Required';
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = 'Invalid email';
    if (!form.password) e.password = 'Required';
    else if (form.password.length < 8) e.password = 'Min 8 characters';
    else if (s < 3) e.password = 'Too weak';
    if (form.password !== form.confirm) e.confirm = 'Passwords do not match';
    if (!agreed) e.agreed = 'Must agree to Terms';
    setErrors(e);
    return !Object.keys(e).length;
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    if (!validate()) return;
    const res = await register(form.name, form.email, form.password);
    if (res.success) { toast.success('Account created! 🎉'); navigate('/'); }
    else toast.error(res.error);
  };

  return (
    <div className="min-h-[calc(100vh-56px)] flex items-center justify-center px-4 py-16">
      <motion.div initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} className="w-full max-w-md">
        <div className="text-center mb-8"><h1 className="page-title">Create Account</h1><p className="text-gray-500 mt-2">Start advertising today</p></div>
        <div className="card p-8">
          <form onSubmit={handleSubmit} noValidate className="space-y-4">
            {[['name','text','Full Name *','Your name or brand',100],['email','email','Email *','you@example.com',255]].map(([k,t,l,ph,max])=>(
              <div key={k}><label className="block text-sm text-gray-400 mb-1.5">{l}</label>
              <input type={t} autoComplete={k} maxLength={max} value={form[k]} onChange={e=>setForm(f=>({...f,[k]:e.target.value}))}
                className={`input ${errors[k]?'input-error':''}`} placeholder={ph}/>
              {errors[k]&&<p className="text-red-400 text-xs mt-1">{errors[k]}</p>}</div>
            ))}
            <div>
              <label className="block text-sm text-gray-400 mb-1.5">Password *</label>
              <input type="password" autoComplete="new-password" value={form.password} onChange={e=>setForm(f=>({...f,password:e.target.value}))}
                className={`input ${errors.password?'input-error':''}`} placeholder="Min 8 chars with upper, number, symbol"/>
              {form.password&&<div className="mt-2"><div className="flex gap-1">{[1,2,3,4].map(i=><div key={i} className={`h-1 flex-1 rounded-full transition-all ${i<=s?colors[s]:'bg-gray-700'}`}/>)}</div><p className={`text-xs mt-1 ${s>=3?'text-green-400':s>=2?'text-yellow-400':'text-red-400'}`}>{labels[s]}</p></div>}
              {errors.password&&<p className="text-red-400 text-xs mt-1">{errors.password}</p>}
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-1.5">Confirm Password *</label>
              <input type="password" autoComplete="new-password" value={form.confirm} onChange={e=>setForm(f=>({...f,confirm:e.target.value}))}
                className={`input ${errors.confirm?'input-error':''}`} placeholder="Repeat password"/>
              {errors.confirm&&<p className="text-red-400 text-xs mt-1">{errors.confirm}</p>}
            </div>
            <div>
              <label className="flex items-start gap-3 cursor-pointer">
                <input type="checkbox" checked={agreed} onChange={e=>setAgreed(e.target.checked)} className="mt-0.5 accent-yellow-500"/>
                <span className="text-sm text-gray-400">I agree to the <Link to="/terms" className="text-yellow-400 hover:underline" target="_blank">Terms of Service</Link></span>
              </label>
              {errors.agreed&&<p className="text-red-400 text-xs mt-1">{errors.agreed}</p>}
            </div>
            <button type="submit" disabled={isLoading} className="btn-primary w-full py-3 text-base mt-2">{isLoading?'Creating...':'Create Account →'}</button>
          </form>
          <div className="divider"/>
          <p className="text-center text-sm text-gray-500">Already have an account? <Link to="/login" className="text-yellow-400 hover:underline">Sign in</Link></p>
        </div>
      </motion.div>
    </div>
  );
}