import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
export default function PaymentCancel() {
  return (
    <div className="min-h-[calc(100vh-56px)] flex items-center justify-center px-4 py-16">
      <motion.div initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} className="text-center max-w-md">
        <div className="text-6xl mb-6">😔</div>
        <h1 className="text-3xl font-black text-white mb-3">Payment Cancelled</h1>
        <p className="text-gray-400 mb-8">No charge was made. Your pixel selection has been released.</p>
        <div className="flex gap-3 justify-center">
          <Link to="/" className="btn-primary">← Back to Grid</Link>
          <Link to="/terms" className="btn-secondary">View Terms</Link>
        </div>
      </motion.div>
    </div>
  );
}