import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import { loadStripe } from '@stripe/stripe-js';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';
import DOMPurify from 'dompurify';
import { usePixelStore } from '../store/pixelStore';
import { useAuthStore } from '../store/authStore';
import api from '../utils/api';

const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_PUBLIC_KEY);
const STEPS = ['Details', 'Upload Image', 'Payment'];

export default function PurchasePage() {
  const navigate = useNavigate();
  const { selectedPixels, clearSelection } = usePixelStore();
  const { user } = useAuthStore();
  const [step, setStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [reservationId, setReservationId] = useState(null);
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [uploadedImageUrl, setUploadedImageUrl] = useState(null);
  const [sessionId] = useState(() => crypto.randomUUID());
  const [form, setForm] = useState({ advertiserName: user?.name||'', websiteUrl:'', description:'' });
  const [errors, setErrors] = useState({});
  const count = selectedPixels.size;

  if (!count) return (
    <div className="min-h-[calc(100vh-56px)] flex items-center justify-center text-white">
      <div className="text-center"><p className="text-xl mb-4">No pixels selected!</p><button onClick={()=>navigate('/')} className="btn-primary">Go Back</button></div>
    </div>
  );

  const validate = () => {
    const e = {};
    if (!form.advertiserName.trim()) e.advertiserName = 'Required';
    if (!form.websiteUrl.trim()) e.websiteUrl = 'Required';
    try { new URL(form.websiteUrl); } catch { e.websiteUrl = 'Invalid URL (include https://)'; }
    if (form.description.length > 500) e.description = 'Max 500 chars';
    setErrors(e);
    return !Object.keys(e).length;
  };

  const handleChange = (e) => {
    const clean = DOMPurify.sanitize(e.target.value, { ALLOWED_TAGS: [] });
    setForm(f => ({ ...f, [e.target.name]: clean }));
  };

  const handleNextToImage = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      const csrf = await api.get('/csrf-token');
      const { data } = await api.post('/pixels/reserve',
        { pixelIds: Array.from(selectedPixels), sessionId },
        { headers: { 'X-CSRF-Token': csrf.data.csrfToken } }
      );
      setReservationId(data.reservationId);
      setStep(1);
      toast.success(`${count} pixels reserved for 15 minutes!`);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to reserve pixels');
    } finally { setLoading(false); }
  };

  const onDrop = useCallback((files) => {
    const file = files[0]; if (!file) return;
    if (file.size > 5*1024*1024) { toast.error('Max 5MB'); return; }
    setImageFile(file); setImagePreview(URL.createObjectURL(file));
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop, accept: {'image/*':['.jpg','.jpeg','.png','.gif','.webp']}, maxFiles:1, maxSize:5*1024*1024
  });

  const handleUpload = async () => {
    if (!imageFile) { toast.error('Please upload an image'); return; }
    setLoading(true);
    try {
      const fd = new FormData(); fd.append('image', imageFile);
      const { data } = await api.post('/payments/upload-ad-image', fd, { headers: {'Content-Type':'multipart/form-data'} });
      setUploadedImageUrl(data.imageUrl); setStep(2);
    } catch { toast.error('Upload failed. Try a different image.'); }
    finally { setLoading(false); }
  };

  const handleStripe = async () => {
    setLoading(true);
    try {
      const stripe = await stripePromise;
      const csrf = await api.get('/csrf-token');
      const { data } = await api.post('/payments/create-stripe-session',
        { pixelIds: Array.from(selectedPixels), reservationId, ...form, imageUrl: uploadedImageUrl },
        { headers: { 'X-CSRF-Token': csrf.data.csrfToken } }
      );
      const res = await stripe.redirectToCheckout({ sessionId: data.sessionId });
      if (res.error) toast.error(res.error.message);
    } catch (err) { toast.error(err.response?.data?.error || 'Payment failed'); }
    finally { setLoading(false); }
  };

  return (
    <div className="min-h-[calc(100vh-56px)] py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-black text-white mb-2">Purchase <span className="text-yellow-400">{count.toLocaleString()} Pixels</span></h1>
          <p className="text-gray-400">Total: <span className="text-green-400 font-bold text-xl">${count.toLocaleString()}</span></p>
        </div>
        <div className="flex justify-center gap-2 mb-8">
          {STEPS.map((s,i)=>(
            <div key={s} className="flex items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all ${i===step?'bg-yellow-500 text-black':i<step?'bg-green-500 text-black':'bg-gray-800 text-gray-500'}`}>{i<step?'✓':i+1}</div>
              {i<STEPS.length-1&&<div className={`w-8 h-0.5 ${i<step?'bg-green-500':'bg-gray-800'}`}/>}
            </div>
          ))}
        </div>

        <AnimatePresence mode="wait">
          {step===0&&(
            <motion.div key="s0" initial={{opacity:0,x:20}} animate={{opacity:1,x:0}} exit={{opacity:0,x:-20}} className="card p-6">
              <h2 className="text-white font-bold text-lg mb-6">Advertisement Details</h2>
              <div className="space-y-4">
                {[['advertiserName','text','Brand Name *','Your company or name',100],['websiteUrl','url','Website URL *','https://yoursite.com',500]].map(([name,type,label,ph,max])=>(
                  <div key={name}><label className="block text-gray-400 text-sm mb-1.5">{label}</label>
                  <input name={name} type={type} value={form[name]} onChange={handleChange} maxLength={max} className={`input ${errors[name]?'input-error':''}`} placeholder={ph}/>
                  {errors[name]&&<p className="text-red-400 text-xs mt-1">{errors[name]}</p>}</div>
                ))}
                <div><label className="block text-gray-400 text-sm mb-1.5">Description (optional)</label>
                <textarea name="description" value={form.description} onChange={handleChange} maxLength={500} rows={3} className="input resize-none" placeholder="Short description..."/></div>
              </div>
              <button onClick={handleNextToImage} disabled={loading} className="btn-primary w-full mt-6 py-3">{loading?'Reserving...':'Continue →'}</button>
            </motion.div>
          )}
          {step===1&&(
            <motion.div key="s1" initial={{opacity:0,x:20}} animate={{opacity:1,x:0}} exit={{opacity:0,x:-20}} className="card p-6">
              <h2 className="text-white font-bold text-lg mb-4">Upload Ad Image</h2>
              <div {...getRootProps()} className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${isDragActive?'border-yellow-400 bg-yellow-400/10':'border-gray-700 hover:border-gray-500'}`}>
                <input {...getInputProps()}/>
                {imagePreview?(<div><img src={imagePreview} alt="Preview" className="max-h-48 mx-auto rounded-lg mb-3 object-contain"/><p className="text-green-400 text-sm">✓ Ready — click to replace</p></div>):
                (<div><div className="text-5xl mb-3">📸</div><p className="text-gray-300">{isDragActive?'Drop it!':'Drag & drop or click'}</p><p className="text-gray-500 text-sm mt-1">JPG, PNG, GIF, WebP — max 5MB</p></div>)}
              </div>
              <div className="flex gap-3 mt-6">
                <button onClick={()=>setStep(0)} className="btn-secondary flex-1 py-3">← Back</button>
                <button onClick={handleUpload} disabled={loading||!imageFile} className="btn-primary flex-1 py-3">{loading?'Uploading...':'Continue →'}</button>
              </div>
            </motion.div>
          )}
          {step===2&&(
            <motion.div key="s2" initial={{opacity:0,x:20}} animate={{opacity:1,x:0}} exit={{opacity:0,x:-20}} className="card p-6">
              <h2 className="text-white font-bold text-lg mb-6">Complete Payment</h2>
              <div className="bg-gray-800 rounded-lg p-4 mb-6">
                <div className="flex justify-between text-sm mb-2"><span className="text-gray-400">{count.toLocaleString()} pixels × $1.00</span><span className="text-white">${count.toLocaleString()}</span></div>
                <div className="border-t border-gray-700 pt-2 flex justify-between font-bold"><span className="text-white">Total</span><span className="text-green-400 text-lg">${count.toLocaleString()}</span></div>
              </div>
              <button onClick={handleStripe} disabled={loading} className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg transition-all disabled:opacity-50 text-lg">
                {loading?'Redirecting...':`💳 Pay $${count.toLocaleString()} with Card →`}
              </button>
              <p className="text-xs text-gray-600 text-center mt-4">🔒 Secured by Stripe. We never store card details.</p>
              <button onClick={()=>setStep(1)} className="w-full mt-3 py-2 text-gray-500 text-sm hover:text-gray-400">← Back</button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}