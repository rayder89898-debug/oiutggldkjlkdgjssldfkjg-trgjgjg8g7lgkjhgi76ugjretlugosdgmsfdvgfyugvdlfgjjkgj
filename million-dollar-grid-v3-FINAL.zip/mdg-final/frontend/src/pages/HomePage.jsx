import React, { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useQuery } from 'react-query';
import PixelGrid from '../components/PixelGrid';
import { usePixelStore } from '../store/pixelStore';
import { useAuthStore } from '../store/authStore';
import api from '../utils/api';
import toast from 'react-hot-toast';

export default function HomePage() {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuthStore();
  const { selectedPixels, clearSelection, fetchSoldAds } = usePixelStore();
  const { data: stats } = useQuery('pixelStats', () => api.get('/pixels/available-count').then(r => r.data), { refetchInterval: 30000 });

  useEffect(() => { fetchSoldAds(); }, []);

  const handlePurchase = () => {
    if (!selectedPixels.size) { toast.error('Select at least 1 pixel first!'); return; }
    if (!isAuthenticated) { toast('Please login to continue', { icon: '🔒' }); navigate('/login'); return; }
    navigate('/purchase');
  };

  const soldPct = stats ? ((parseInt(stats.sold) / 10000000) * 100).toFixed(2) : 0;

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <motion.section initial={{opacity:0,y:-20}} animate={{opacity:1,y:0}} className="relative py-16 px-4 text-center">
        <div className="absolute inset-0 bg-gradient-to-b from-yellow-500/5 to-transparent pointer-events-none"/>
        <h1 className="page-title mb-4">Million Dollar Grid</h1>
        <p className="text-xl text-gray-400 mb-2 max-w-2xl mx-auto">Own a piece of internet history. <strong className="text-yellow-400">$1 per pixel.</strong></p>
        <p className="text-sm text-gray-500 mb-8">10,000,000 pixels · permanent advertising</p>
        <div className="flex flex-wrap justify-center gap-8 mb-8">
          {[['Pixels Sold',stats?parseInt(stats.sold).toLocaleString():'—','text-green-400'],['Available',stats?parseInt(stats.available).toLocaleString():'—','text-yellow-400'],['Completion',`${soldPct}%`,'text-blue-400'],['Revenue',stats?`$${parseInt(stats.sold).toLocaleString()}`:'—','text-purple-400']].map(([label,value,color])=>(
            <div key={label} className="text-center"><p className={`text-2xl font-black ${color}`}>{value}</p><p className="text-xs text-gray-500 uppercase tracking-wider">{label}</p></div>
          ))}
        </div>
        <div className="max-w-4xl mx-auto mb-8">
          <div className="w-full h-4 bg-gray-800 rounded-full overflow-hidden">
            <motion.div className="h-full bg-gradient-to-r from-yellow-500 to-amber-400 rounded-full" initial={{width:0}} animate={{width:`${soldPct}%`}} transition={{duration:1.5}}/>
          </div>
          <p className="text-xs text-gray-500 mt-1">{soldPct}% filled</p>
        </div>
      </motion.section>

      <section className="px-4 pb-8">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-green-400 animate-pulse"/><span className="text-sm text-gray-400">Live updates</span></div>
          <div className="flex gap-3 text-xs text-gray-500">
            <span className="flex items-center gap-1"><span className="w-3 h-3 bg-gray-700 rounded-sm"/> Available</span>
            <span className="flex items-center gap-1"><span className="w-3 h-3 bg-yellow-400/50 rounded-sm"/> Selected</span>
            <span className="flex items-center gap-1"><span className="w-3 h-3 bg-blue-500 rounded-sm"/> Sold</span>
          </div>
        </div>
        <PixelGrid/>
        {selectedPixels.size>0&&(
          <motion.div initial={{opacity:0}} animate={{opacity:1}} className="mt-6 p-4 bg-gray-900 border border-yellow-500/50 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4">
            <div><p className="text-white font-semibold"><span className="text-yellow-400 text-2xl font-black">{selectedPixels.size.toLocaleString()}</span> pixels selected</p><p className="text-gray-400 text-sm">Total: <span className="text-green-400 font-semibold">${selectedPixels.size.toLocaleString()}</span></p></div>
            <div className="flex gap-3">
              <button onClick={clearSelection} className="btn-secondary text-sm py-2">Clear</button>
              <button onClick={handlePurchase} className="btn-primary text-sm py-2">Advertise Now →</button>
            </div>
          </motion.div>
        )}
      </section>

      <footer className="py-8 text-center text-gray-600 text-sm border-t border-gray-800">
        <div className="flex flex-wrap justify-center gap-6 mb-3">
          <Link to="/advertised" className="hover:text-gray-400">All Advertisers</Link>
          <Link to="/top-ads" className="hover:text-gray-400">Top Ads</Link>
          <Link to="/terms" className="hover:text-gray-400">Terms</Link>
        </div>
        <p>© 2025 Million Dollar Grid. All rights reserved.</p>
      </footer>
    </div>
  );
}