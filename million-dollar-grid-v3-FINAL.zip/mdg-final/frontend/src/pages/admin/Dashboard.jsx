import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from 'react-query';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { format } from 'date-fns';
import api from '../../utils/api';
import { useAuthStore } from '../../store/authStore';

export default function AdminDashboard() {
  const { getAdminPath } = useAuthStore();
  const ap = getAdminPath();
  const { data, isLoading } = useQuery('adminDashboard', ()=>api.get(`/${ap}/dashboard`).then(r=>r.data), { refetchInterval:60000 });
  if (isLoading) return <div className="min-h-screen bg-gray-950 flex items-center justify-center"><p className="text-yellow-400 animate-pulse">Loading...</p></div>;
  const stats = data?.stats || {};
  const revenueData = data?.revenueByDay?.map(d=>({date:format(new Date(d.date),'MMM d'),revenue:parseFloat(d.revenue)})) || [];
  const statCards=[['💵','Total Revenue',`$${parseFloat(stats.total_revenue||0).toLocaleString()}`,'text-green-400'],['🟩','Pixels Sold',parseInt(stats.pixels_sold||0).toLocaleString(),'text-yellow-400'],['⬜','Available',parseInt(stats.pixels_available||0).toLocaleString(),'text-blue-400'],['⏳','Pending Reviews',stats.pending_reviews||0,'text-orange-400'],['📢','Active Ads',stats.active_ads||0,'text-purple-400'],['👆','Total Clicks',parseInt(stats.total_clicks||0).toLocaleString(),'text-pink-400'],['👥','Advertisers',stats.total_advertisers||0,'text-cyan-400'],['📈','Payments 30d',stats.payments_last_30d||0,'text-indigo-400']];
  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <div className="bg-gray-900 border-b border-gray-800 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto flex-wrap gap-3">
          <div><h1 className="text-xl font-black text-yellow-400">Admin Dashboard</h1><p className="text-gray-500 text-sm">Million Dollar Grid</p></div>
          <div className="flex gap-2 flex-wrap">
            {[['📢 Ads',`/${ap}/advertisements`],['💰 Payments',`/${ap}/payments`],['👥 Users',`/${ap}/users`],['📊 Stats',`/${ap}/stats`]].map(([l,to])=>(
              <Link key={to} to={to} className="text-sm text-gray-400 hover:text-white border border-gray-700 hover:border-gray-500 px-3 py-1.5 rounded-lg transition-all">{l}</Link>
            ))}
            <Link to="/" className="text-sm text-gray-500 hover:text-gray-300 px-3 py-1">← Site</Link>
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {statCards.map(([icon,label,value,color])=>(
            <div key={label} className="card p-4"><p className="text-2xl mb-1">{icon}</p><p className={`text-2xl font-black ${color}`}>{value}</p><p className="text-xs text-gray-500 uppercase tracking-wide">{label}</p></div>
          ))}
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="card p-6"><h2 className="text-white font-bold mb-4">Revenue (30 Days)</h2>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={revenueData}><CartesianGrid strokeDasharray="3 3" stroke="#374151"/><XAxis dataKey="date" stroke="#6b7280" tick={{fontSize:11}}/><YAxis stroke="#6b7280" tick={{fontSize:11}} tickFormatter={v=>`$${v}`}/><Tooltip contentStyle={{background:'#1f2937',border:'1px solid #374151',borderRadius:8}} formatter={v=>[`$${v}`,'Revenue']}/><Line type="monotone" dataKey="revenue" stroke="#f59e0b" strokeWidth={2} dot={false}/></LineChart>
            </ResponsiveContainer>
          </div>
          <div className="card p-6"><div className="flex justify-between items-center mb-4"><h2 className="text-white font-bold">Recent Payments</h2><Link to={`/${ap}/payments`} className="text-yellow-400 text-sm hover:underline">View All</Link></div>
            <div className="space-y-2">
              {data?.recentPayments?.slice(0,5).map(p=>(
                <div key={p.id} className="flex justify-between py-2 border-b border-gray-800">
                  <div><p className="text-sm text-white">{p.name}</p><p className="text-xs text-gray-500">{p.payment_method}</p></div>
                  <div className="text-right"><p className="text-sm font-bold text-green-400">${parseFloat(p.amount).toFixed(2)}</p><span className={`text-xs px-1.5 py-0.5 rounded-full ${p.status==='completed'?'badge-green':'badge-yellow'}`}>{p.status}</span></div>
                </div>
              ))}
              {!data?.recentPayments?.length&&<p className="text-gray-500 text-sm">No payments yet</p>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}