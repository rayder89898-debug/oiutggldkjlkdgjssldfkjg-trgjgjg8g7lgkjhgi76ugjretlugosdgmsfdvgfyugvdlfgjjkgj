import React from 'react';
import { useQuery } from 'react-query';
import api from '../../utils/api';
import { useAuthStore } from '../../store/authStore';
export default function AdminUsers() {
  const { getAdminPath } = useAuthStore(); const ap = getAdminPath();
  const { data=[], isLoading } = useQuery('adminUsers', ()=>api.get(`/${ap}/users`).then(r=>r.data));
  return (
    <div className="min-h-screen bg-gray-950 text-white p-6">
      <h1 className="text-2xl font-black text-yellow-400 mb-6">Users ({data.length})</h1>
      {isLoading?<p className="text-gray-400 animate-pulse">Loading...</p>:(
        <div className="space-y-3">
          {data.map(u=>(
            <div key={u.id} className="card p-4 flex justify-between">
              <div><p className="text-white font-semibold">{u.name}</p><p className="text-gray-500 text-sm">{u.email} · <span className={`capitalize ${u.role==='superadmin'?'text-yellow-400':u.role==='admin'?'text-blue-400':'text-gray-400'}`}>{u.role}</span></p></div>
              <div className="text-right"><p className="text-yellow-400 text-sm">{u.ad_count} ads</p><p className="text-green-400 text-sm">${parseFloat(u.total_spent||0).toFixed(2)}</p>{u.is_banned&&<span className="badge-red text-xs">Banned</span>}</div>
            </div>
          ))}
          {!data.length&&<p className="text-gray-500">No users yet</p>}
        </div>
      )}
    </div>
  );
}