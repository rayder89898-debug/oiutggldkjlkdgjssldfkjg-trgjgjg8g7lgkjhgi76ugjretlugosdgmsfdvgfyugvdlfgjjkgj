import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import toast from 'react-hot-toast';
import api from '../../utils/api';
import { useAuthStore } from '../../store/authStore';
const TABS=['pending','active','rejected','suspended','all'];
export default function AdminAdvertisements() {
  const { getAdminPath } = useAuthStore(); const ap = getAdminPath();
  const [tab,setTab]=useState('pending'), [reviewing,setReviewing]=useState(null), [reason,setReason]=useState('');
  const qc = useQueryClient();
  const { data, isLoading } = useQuery(['adminAds',tab], ()=>api.get(`/${ap}/advertisements?status=${tab}`).then(r=>r.data), { keepPreviousData:true });
  const reviewMut = useMutation(({id,action,reason})=>api.patch(`/${ap}/advertisements/${id}/review`,{action,reason}),{onSuccess:(_,{action})=>{toast.success(`Ad ${action}d`);setReviewing(null);setReason('');qc.invalidateQueries('adminAds');qc.invalidateQueries('adminDashboard');},onError:()=>toast.error('Failed')});
  const deleteMut = useMutation((id)=>api.delete(`/${ap}/advertisements/${id}`),{onSuccess:()=>{toast.success('Deleted');qc.invalidateQueries('adminAds');},onError:()=>toast.error('Failed')});
  const act=(ad,action)=>{if(action==='reject'){setReviewing({...ad});return;}if(action==='delete'){if(window.confirm('Delete and release pixels?'))deleteMut.mutate(ad.id);return;}reviewMut.mutate({id:ad.id,action});};
  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <div className="bg-gray-900 border-b border-gray-800 px-6 py-4"><h1 className="text-xl font-black text-yellow-400">Advertisement Management</h1></div>
      <div className="max-w-7xl mx-auto px-6 py-6">
        <div className="flex gap-2 mb-6 overflow-x-auto">
          {TABS.map(t=><button key={t} onClick={()=>setTab(t)} className={`px-4 py-2 rounded-lg text-sm capitalize font-medium whitespace-nowrap transition-all ${tab===t?'bg-yellow-500 text-black':'bg-gray-800 text-gray-400 hover:bg-gray-700'}`}>{t}</button>)}
        </div>
        {isLoading?<p className="text-yellow-400 animate-pulse">Loading...</p>:(
          <div className="space-y-4">
            {data?.advertisements?.map(ad=>(
              <div key={ad.id} className="card p-4">
                <div className="flex gap-4">
                  {ad.image_url&&<img src={ad.image_url} alt={ad.advertiser_name} className="w-20 h-14 object-cover rounded-lg bg-gray-800 flex-shrink-0" onError={e=>e.target.style.display='none'}/>}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div><p className="text-white font-semibold">{ad.advertiser_name}</p><a href={ad.website_url} target="_blank" rel="noopener noreferrer" className="text-blue-400 text-sm hover:underline truncate block">{ad.website_url}</a></div>
                      <span className={`text-xs px-2 py-0.5 rounded-full border capitalize flex-shrink-0 ${ad.status==='active'?'badge-green':ad.status==='pending'?'badge-yellow':ad.status==='rejected'?'badge-red':'badge-orange'}`}>{ad.status}</span>
                    </div>
                    <div className="flex flex-wrap gap-3 mt-2 text-xs text-gray-500">
                      <span>📧 {ad.advertiser_email}</span><span>🟩 {ad.pixel_count?.toLocaleString()} px</span><span>💵 ${parseFloat(ad.payment_amount||0).toFixed(2)}</span><span>👆 {ad.click_count?.toLocaleString()}</span>
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 flex-shrink-0">
                    {ad.status==='pending'&&<><button onClick={()=>act(ad,'approve')} disabled={reviewMut.isLoading} className="px-3 py-1.5 bg-green-600 hover:bg-green-500 text-white text-xs rounded-lg disabled:opacity-50">✓ Approve</button><button onClick={()=>act(ad,'reject')} disabled={reviewMut.isLoading} className="px-3 py-1.5 bg-red-700 hover:bg-red-600 text-white text-xs rounded-lg disabled:opacity-50">✗ Reject</button></>}
                    {ad.status==='active'&&<button onClick={()=>act(ad,'suspend')} disabled={reviewMut.isLoading} className="px-3 py-1.5 bg-yellow-700 hover:bg-yellow-600 text-white text-xs rounded-lg disabled:opacity-50">⏸ Suspend</button>}
                    {ad.status==='suspended'&&<button onClick={()=>act(ad,'approve')} disabled={reviewMut.isLoading} className="px-3 py-1.5 bg-green-700 hover:bg-green-600 text-white text-xs rounded-lg disabled:opacity-50">▶ Restore</button>}
                    <button onClick={()=>act(ad,'delete')} disabled={deleteMut.isLoading} className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-red-400 text-xs rounded-lg disabled:opacity-50">🗑 Delete</button>
                  </div>
                </div>
              </div>
            ))}
            {!data?.advertisements?.length&&<div className="text-center py-12 text-gray-500">No {tab} advertisements</div>}
          </div>
        )}
      </div>
      {reviewing&&(
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="card p-6 max-w-md w-full">
            <h2 className="text-white font-bold text-lg mb-2">Reject Ad</h2>
            <p className="text-gray-400 text-sm mb-4">From: <strong>{reviewing.advertiser_name}</strong></p>
            <textarea value={reason} onChange={e=>setReason(e.target.value)} placeholder="Reason for rejection (required)..." className="input h-24 resize-none"/>
            <div className="flex gap-3 mt-4">
              <button onClick={()=>setReviewing(null)} className="btn-secondary flex-1 py-2 text-sm">Cancel</button>
              <button onClick={()=>reviewMut.mutate({id:reviewing.id,action:'reject',reason})} disabled={!reason.trim()||reviewMut.isLoading} className="flex-1 py-2 bg-red-600 hover:bg-red-500 text-white font-bold rounded-lg text-sm disabled:opacity-50">Confirm Rejection</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}