import React from 'react';
import { useQuery } from 'react-query';
import api from '../../utils/api';
import { useAuthStore } from '../../store/authStore';
export default function AdminPayments() {
  const { getAdminPath } = useAuthStore(); const ap = getAdminPath();
  const { data=[], isLoading } = useQuery('adminPayments', ()=>api.get(`/${ap}/payments`).then(r=>r.data));
  return (
    <div className="min-h-screen bg-gray-950 text-white p-6">
      <h1 className="text-2xl font-black text-yellow-400 mb-6">Payments ({data.length})</h1>
      {isLoading?<p className="text-gray-400 animate-pulse">Loading...</p>:(
        <div className="space-y-3">
          {data.map(p=>(
            <div key={p.id} className="card p-4 flex justify-between">
              <div><p className="text-white font-semibold">{p.name}</p><p className="text-gray-500 text-sm">{p.email} · {p.payment_method}</p></div>
              <div className="text-right"><p className="text-green-400 font-bold">${parseFloat(p.amount).toFixed(2)}</p><span className={`text-xs px-2 py-0.5 rounded-full ${p.status==='completed'?'badge-green':'badge-yellow'}`}>{p.status}</span></div>
            </div>
          ))}
          {!data.length&&<p className="text-gray-500">No payments yet</p>}
        </div>
      )}
    </div>
  );
}