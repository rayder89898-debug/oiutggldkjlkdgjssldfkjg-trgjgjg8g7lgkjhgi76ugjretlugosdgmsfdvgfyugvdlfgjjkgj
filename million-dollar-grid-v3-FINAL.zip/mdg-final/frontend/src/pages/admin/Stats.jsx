import React from 'react';
import { useQuery } from 'react-query';
import api from '../../utils/api';
import { useAuthStore } from '../../store/authStore';
export default function AdminStats() {
  const { getAdminPath } = useAuthStore(); const ap = getAdminPath();
  const { data, isLoading } = useQuery('adminStats', ()=>api.get(`/${ap}/stats/detailed`).then(r=>r.data));
  return (
    <div className="min-h-screen bg-gray-950 text-white p-6">
      <h1 className="text-2xl font-black text-yellow-400 mb-6">Statistics</h1>
      {isLoading?<p className="text-gray-400 animate-pulse">Loading...</p>:(
        <div className="grid md:grid-cols-2 gap-6">
          <div className="card p-6"><h2 className="text-white font-bold mb-4">Top Ads by Clicks</h2>
            {data?.topAds?.map((ad,i)=>(<div key={ad.id} className="flex justify-between py-2 border-b border-gray-800 text-sm"><span className="text-gray-300">{i+1}. {ad.advertiser_name}</span><span className="text-yellow-400">{ad.click_count} clicks</span></div>))}
            {!data?.topAds?.length&&<p className="text-gray-500 text-sm">No data yet</p>}
          </div>
          <div className="card p-6"><h2 className="text-white font-bold mb-4">Payment Methods</h2>
            {data?.paymentMethods?.map(m=>(<div key={m.payment_method} className="flex justify-between py-2 border-b border-gray-800 text-sm"><span className="text-gray-300 capitalize">{m.payment_method}</span><span className="text-green-400">{m.count} (${parseFloat(m.total||0).toFixed(0)})</span></div>))}
            {!data?.paymentMethods?.length&&<p className="text-gray-500 text-sm">No data yet</p>}
          </div>
        </div>
      )}
    </div>
  );
}