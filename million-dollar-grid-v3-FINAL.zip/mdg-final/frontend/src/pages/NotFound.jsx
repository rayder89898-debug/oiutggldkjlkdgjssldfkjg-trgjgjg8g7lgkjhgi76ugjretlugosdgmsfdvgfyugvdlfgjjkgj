import React from 'react';
import { Link } from 'react-router-dom';
export default function NotFound() {
  return (
    <div className="min-h-[calc(100vh-56px)] flex items-center justify-center px-4">
      <div className="text-center">
        <p className="text-9xl font-display text-yellow-500/20 mb-4">404</p>
        <h1 className="text-3xl font-black text-white mb-3">Page Not Found</h1>
        <p className="text-gray-500 mb-8">Maybe buy those pixels?</p>
        <Link to="/" className="btn-primary">← Back to Grid</Link>
      </div>
    </div>
  );
}