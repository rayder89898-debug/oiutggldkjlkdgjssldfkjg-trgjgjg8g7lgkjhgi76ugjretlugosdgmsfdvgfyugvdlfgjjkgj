import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import confetti from 'canvas-confetti';
import { usePixelStore } from '../store/pixelStore';
export default function PaymentSuccess() {
  const { clearSelection, fetchSoldAds } = usePixelStore();
  useEffect(()=>{
    clearSelection(); fetchSoldAds();
    const fire=(x,y)=>confetti({particleCount:80,angle:x<0.5?60:120,spread:55,origin:{x,y},colors:['#f59e0b','#fbbf24','#fff']});
    setTimeout(()=>{fire(0.2,0.6);fire(0.8,0.6);},200);
    setTimeout(()=>fire(0.5,0.5),600);
  },[]);
  return (
    <div className="min-h-[calc(100vh-56px)] flex items-center justify-center px-4 py-16">
      <motion.div initial={{opacity:0,scale:0.9}} animate={{opacity:1,scale:1}} transition={{type:'spring',stiffness:200,damping:20}} className="text-center max-w-md">
        <div className="text-7xl mb-6">🎉</div>
        <h1 className="page-title mb-3">Payment Successful!</h1>
        <p className="text-gray-400 mb-2">Your pixels are reserved and your ad is under review.</p>
        <p className="text-gray-500 text-sm mb-8">Once approved, your advertisement goes live immediately.</p>
        <div className="card p-5 mb-6 text-left">
          <h3 className="text-white font-semibold mb-3 text-sm">What happens next?</h3>
          <ol className="space-y-2 text-sm text-gray-400">
            {['Our team reviews your ad within 24h','Upon approval, your image appears on the grid','Visitors click your ad to visit your site','Track clicks in real time'].map((s,i)=>(
              <li key={i} className="flex gap-2"><span className="text-yellow-400 font-bold">{i+1}.</span>{s}</li>
            ))}
          </ol>
        </div>
        <div className="flex gap-3 justify-center">
          <Link to="/" className="btn-primary">View Grid →</Link>
          <Link to="/advertised" className="btn-secondary">All Advertisers</Link>
        </div>
      </motion.div>
    </div>
  );
}