import React from 'react';
import { motion } from 'framer-motion';
const SECTIONS=[
  ['1. Acceptance','By using Million Dollar Grid, you agree to these Terms.'],
  ['2. Pixel Purchases','All purchases are final. $1 per pixel. Max 10,000 per transaction. No refunds except for technical failure on our part.'],
  ['3. Content Guidelines','Prohibited: illegal content, adult/NSFW, malware, misleading ads, hateful content. Violations result in immediate removal without refund.'],
  ['4. Image Requirements','JPEG, PNG, GIF, or WebP only. Max 5MB. Max 5000x5000px. We reserve the right to reject any image.'],
  ['5. Review Process','All ads reviewed within 24-48 hours. Rejected ads receive full refund within 5 business days.'],
  ['6. Privacy','Payment data handled by Stripe/PayPal. We never store card details. We collect anonymous click analytics.'],
  ['7. Intellectual Property','You own or have rights to all content. You grant us license to display your ad on the site.'],
  ['8. Liability','Not liable for indirect damages. Total liability does not exceed the amount you paid.'],
  ['9. Changes','We may modify these terms at any time. Continued use constitutes acceptance.'],
  ['10. Contact','Questions: legal@milliondollargrid.com'],
];
export default function TermsPage() {
  return (
    <div className="min-h-[calc(100vh-56px)] px-4 py-12">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-10"><h1 className="page-title">Terms of Service</h1><p className="text-gray-500 mt-2 text-sm">Last updated: January 2025</p></div>
        <div className="space-y-4">
          {SECTIONS.map(([title,body],i)=>(
            <motion.div key={i} initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} transition={{delay:i*0.04}} className="card p-6">
              <h2 className="text-white font-bold mb-2">{title}</h2>
              <p className="text-gray-400 text-sm leading-relaxed">{body}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}