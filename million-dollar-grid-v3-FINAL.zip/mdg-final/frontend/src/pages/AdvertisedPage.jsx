import React from 'react';
import { useQuery } from 'react-query';
import { motion } from 'framer-motion';
import api from '../utils/api';
export default function AdvertisedPage() {
  const { data:ads=[], isLoading } = useQuery('allAds', ()=>api.get('/pixels/sold').then(r=>r.data));
  return (
    <div className="min-h-[calc(100vh-56px)] px-4 py-12">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-10"><h1 className="page-title">All Advertisers</h1><p className="text-gray-500 mt-2">{ads.length} active advertisements</p></div>
        {isLoading?<div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{[...Array(6)].map((_,i)=><div key={i} className="skeleton h-40 rounded-xl"/>)}</div>:(
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {ads.map((ad,i)=>(
              <motion.a key={ad.id} href={ad.website_url} target="_blank" rel="noopener noreferrer"
                initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} transition={{delay:Math.min(i*0.03,0.3)}}
                className="card-hover p-4 flex flex-col gap-3 group">
                {ad.image_url&&<img src={ad.image_url} alt={ad.advertiser_name} className="w-full h-32 object-cover rounded-lg bg-gray-800" loading="lazy" onError={e=>e.target.style.display='none'}/>}
                <div><p className="text-white font-semibold group-hover:text-yellow-400 transition-colors">{ad.advertiser_name}</p><p className="text-blue-400 text-sm truncate">{ad.website_url}</p></div>
                <div className="flex gap-3 text-xs text-gray-500"><span>🟩 {parseInt(ad.pixel_count).toLocaleString()} px</span><span>👆 {parseInt(ad.click_count).toLocaleString()}</span></div>
              </motion.a>
            ))}
            {!ads.length&&<div className="col-span-3 text-center py-16 text-gray-500">No advertisements yet.</div>}
          </div>
        )}
      </div>
    </div>
  );
}