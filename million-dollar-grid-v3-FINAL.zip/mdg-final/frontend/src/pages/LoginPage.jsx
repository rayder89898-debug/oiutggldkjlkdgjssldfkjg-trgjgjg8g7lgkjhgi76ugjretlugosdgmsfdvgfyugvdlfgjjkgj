import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { useAuthStore } from '../store/authStore';

export default function LoginPage() {
  const navigate = useNavigate();
  const { login, isLoading } = useAuthStore();
  const [form, setForm] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});

  const validate = () => {
    const e = {};
    if (!form.email) e.email = 'Required';
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = 'Invalid email';
    if (!form.password) e.password = 'Required';
    setErrors(e);
    return !Object.keys(e).length;
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    if (!validate()) return;
    const res = await login(form.email, form.password);
    if (res.success) { toast.success('Welcome back!'); navigate('/'); }
    else toast.error(res.error);
  };

  return (
    <div className="min-h-[calc(100vh-56px)] flex items-center justify-center px-4 py-16">
      <motion.div initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} className="w-full max-w-md">
        <div className="text-center mb-8"><h1 className="page-title">Welcome Back</h1><p className="text-gray-500 mt-2">Log in to your account</p></div>
        <div className="card p-8">
          <form onSubmit={handleSubmit} noValidate className="space-y-5">
            {[['email','email','Email','you@example.com'],['password','password','Password','••••••••']].map(([name,type,label,ph])=>(
              <div key={name}>
                <label className="block text-sm text-gray-400 mb-1.5">{label}</label>
                <input type={type} autoComplete={name} value={form[name]} onChange={e=>setForm(f=>({...f,[name]:e.target.value}))}
                  className={`input ${errors[name]?'input-error':''}`} placeholder={ph}/>
                {errors[name]&&<p className="text-red-400 text-xs mt-1">{errors[name]}</p>}
              </div>
            ))}
            <button type="submit" disabled={isLoading} className="btn-primary w-full py-3 text-base">{isLoading?'Signing in...':'Sign In'}</button>
          </form>
          <div className="divider"/>
          <p className="text-center text-sm text-gray-500">No account? <Link to="/register" className="text-yellow-400 hover:underline font-medium">Create one</Link></p>
        </div>
      </motion.div>
    </div>
  );
}