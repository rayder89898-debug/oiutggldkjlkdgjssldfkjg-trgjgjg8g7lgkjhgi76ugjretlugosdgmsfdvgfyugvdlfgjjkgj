import React from 'react';
import { useQuery } from 'react-query';
import { motion } from 'framer-motion';
import api from '../utils/api';
export default function TopAdsPage() {
  const { data:ads=[], isLoading } = useQuery('topAds', ()=>api.get('/pixels/sold').then(r=>r.data.sort((a,b)=>b.click_count-a.click_count)));
  return (
    <div className="min-h-[calc(100vh-56px)] px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-10"><h1 className="page-title">🏆 Top Advertisers</h1><p className="text-gray-500 mt-2">Ranked by clicks</p></div>
        {isLoading?<div className="space-y-3">{[...Array(5)].map((_,i)=><div key={i} className="skeleton h-20 rounded-xl"/>)}</div>:(
          <div className="space-y-3">
            {ads.map((ad,i)=>(
              <motion.a key={ad.id} href={ad.website_url} target="_blank" rel="noopener noreferrer"
                initial={{opacity:0,x:-20}} animate={{opacity:1,x:0}} transition={{delay:i*0.04}}
                className="card-hover flex items-center gap-4 p-4 group">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-black text-lg flex-shrink-0 ${i===0?'bg-yellow-500 text-black':i===1?'bg-gray-400 text-black':i===2?'bg-amber-700 text-white':'bg-gray-800 text-gray-400'}`}>{i+1}</div>
                {ad.image_url?<img src={ad.image_url} alt={ad.advertiser_name} className="w-14 h-14 object-cover rounded-lg bg-gray-800 flex-shrink-0" onError={e=>e.target.style.display='none'}/>:<div className="w-14 h-14 rounded-lg bg-gray-800 flex-shrink-0 flex items-center justify-center text-2xl">📢</div>}
                <div className="flex-1 min-w-0"><p className="text-white font-semibold group-hover:text-yellow-400 transition-colors truncate">{ad.advertiser_name}</p><p className="text-blue-400 text-sm truncate">{ad.website_url}</p></div>
                <div className="text-right flex-shrink-0"><p className="text-white font-bold">{parseInt(ad.click_count).toLocaleString()}</p><p className="text-gray-500 text-xs">clicks</p><p className="text-yellow-400 text-xs">{parseInt(ad.pixel_count).toLocaleString()} px</p></div>
              </motion.a>
            ))}
            {!ads.length&&<div className="text-center py-16 text-gray-500">No ads yet — be the first!</div>}
          </div>
        )}
      </div>
    </div>
  );
}