import { useEffect, useRef, useState, useCallback } from 'react';
import { usePixelStore } from '../store/pixelStore';

const WS_URL = process.env.REACT_APP_WS_URL || 'ws://localhost:5000/ws';

export function useWebSocket() {
  const ws = useRef(null);
  const reconnectCount = useRef(0);
  const reconnectTimer = useRef(null);
  const pingInterval = useRef(null);
  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState(null);

  const handleMessage = useCallback((raw) => {
    try {
      const msg = JSON.parse(raw);
      setLastMessage(raw);
      const store = usePixelStore.getState();
      if (msg.type === 'PIXELS_SOLD') { store.updatePixelStatuses(msg.pixelIds||[], 'sold'); store.fetchSoldAds(); }
      else if (msg.type === 'PIXELS_RESERVED') store.updatePixelStatuses(msg.pixelIds||[], 'reserved');
      else if (msg.type === 'PIXELS_RELEASED') store.updatePixelStatuses(msg.pixelIds||[], 'available');
      else if (['AD_STATUS_CHANGED','AD_DELETED'].includes(msg.type)) store.fetchSoldAds();
    } catch {}
  }, []);

  const connect = useCallback(() => {
    if (ws.current?.readyState === WebSocket.OPEN) return;
    try {
      ws.current = new WebSocket(WS_URL);
      ws.current.onopen = () => {
        setIsConnected(true); reconnectCount.current = 0;
        pingInterval.current = setInterval(() => {
          if (ws.current?.readyState === WebSocket.OPEN) ws.current.send(JSON.stringify({ type: 'PING' }));
        }, 25000);
      };
      ws.current.onmessage = (e) => handleMessage(e.data);
      ws.current.onclose = (e) => {
        setIsConnected(false); clearInterval(pingInterval.current);
        if (e.code !== 1000 && reconnectCount.current < 10) {
          reconnectCount.current++;
          reconnectTimer.current = setTimeout(connect, 3000 * Math.min(reconnectCount.current, 5));
        }
      };
      ws.current.onerror = () => {};
    } catch {}
  }, [handleMessage]);

  useEffect(() => {
    connect();
    return () => { clearTimeout(reconnectTimer.current); clearInterval(pingInterval.current); ws.current?.close(1000); };
  }, [connect]);

  return { isConnected, lastMessage };
}